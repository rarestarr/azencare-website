# AzenCare Website

A modern healthcare platform connecting therapists (OT, PT, SLP) with clients through intelligent zip code matching.

![AzenCare Platform](https://images.unsplash.com/photo-1559757148-5c350d0d3c56?auto=format&fit=crop&w=1200&h=400&q=80)

## 🏥 About AzenCare

AzenCare is revolutionizing healthcare access by creating a seamless connection between licensed therapists and families in need of therapy services. Our platform focuses on:

- **Occupational Therapy (OT)**
- **Physical Therapy (PT)**  
- **Speech-Language Pathology (SLP)**

## 🚀 Features

### For Therapists
- **Early Access Signup** - Join our founding therapist network
- **Location-Based Matching** - Connect with clients in your service area
- **Professional Dashboard** - Manage your practice efficiently

### For Investors
- **Platform Statistics** - Real-time growth metrics and user engagement
- **Market Analysis** - Comprehensive healthcare market insights
- **Revenue Projections** - Detailed financial forecasting

### For Partners & Grants
- **Compliance Documentation** - HIPAA-compliant architecture
- **Partnership Opportunities** - Collaboration frameworks
- **Grant Application Support** - Documentation and reporting tools

## 🛠 Tech Stack

- **Frontend**: React 18 + TypeScript + Next.js 14
- **Styling**: Tailwind CSS v4 + ShadCN UI Components
- **Backend**: Supabase (Database + Auth + Edge Functions)
- **Icons**: Lucide React
- **Charts**: Recharts
- **Deployment**: Vercel/Netlify Ready

## 📋 Prerequisites

- Node.js 18+ 
- npm or yarn
- Supabase account (for backend functionality)

## 🚀 Quick Start

### 1. Clone & Install
```bash
git clone https://github.com/yourusername/azencare-website.git
cd azencare-website
npm install
```

### 2. Environment Setup
Create `.env.local` file:
```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
```

### 3. Run Development Server
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to view the website.

## 📁 Project Structure

```
azencare-website/
├── App.tsx                 # Main application entry point
├── components/             # React components
│   ├── ui/                # ShadCN UI components
│   ├── figma/             # Figma integration components
│   ├── CleanHero.tsx      # Hero section
│   ├── TherapistSection.tsx # Therapist recruitment
│   ├── InvestorSection.tsx  # Investor information
│   └── ...                # Other components
├── supabase/              # Supabase backend
│   └── functions/         # Edge functions
├── styles/                # Global styles
│   └── globals.css        # Tailwind v4 configuration
├── utils/                 # Utility functions
└── guidelines/            # Project guidelines
```

## 🎨 Design System

AzenCare uses a professional healthcare design system with:

- **Primary Colors**: Blue (#2563eb), Teal (#0ea5e9)
- **Typography**: System fonts optimized for readability
- **Components**: Consistent ShadCN UI component library
- **Responsive**: Mobile-first design approach

## 🔐 Security & Compliance

- **HIPAA Compliance**: Built with healthcare data protection standards
- **Secure Authentication**: Supabase Auth with row-level security
- **Data Encryption**: End-to-end encryption for sensitive information
- **Privacy Controls**: Granular user privacy settings

## 📊 Analytics & Tracking

The platform includes comprehensive analytics for:

- **User Engagement**: Therapist signup rates and client inquiries
- **Geographic Coverage**: Service area expansion tracking
- **Platform Growth**: Real-time statistics for investor presentations

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📜 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👨‍⚕️ About the Founder

**Alexander Azenabor, OTR/L**
- Licensed Occupational Therapist
- Healthcare Technology Entrepreneur
- Pediatric Therapy Specialist

## 📞 Contact

- **Website**: [azencare.com](https://azencare.com)
- **Email**: hello@azencare.com
- **LinkedIn**: [Alexander Azenabor](https://linkedin.com/in/alexander-azenabor)

## 🎯 Funding

Currently seeking $2.5M Series A funding. Contact us for investor deck and financial projections.

---

**Built with ❤️ by the AzenCare Team**