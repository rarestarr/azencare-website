import { createClient } from '@supabase/supabase-js'
import { projectId, publicAnonKey } from './info'

// Create a single supabase client for interacting with your database
export const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
)

// API client for backend calls
export class AzenCareAPI {
  private baseUrl: string
  private headers: Record<string, string>

  constructor() {
    this.baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-7d2f6d57`
    this.headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`
    }
  }

  async submitTherapistInterest(data: {
    firstName: string
    lastName: string
    practiceArea: string
    phone: string
  }) {
    const response = await fetch(`${this.baseUrl}/therapist/interest`, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify(data)
    })
    
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Submission failed')
    }
    
    return response.json()
  }

  async registerClient(data: {
    email: string
    password: string
    firstName: string
    lastName: string
    zipCode: string
    phone?: string
    therapyNeeds?: string
  }) {
    const response = await fetch(`${this.baseUrl}/client/register`, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify(data)
    })
    
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Registration failed')
    }
    
    return response.json()
  }

  async login(email: string, password: string) {
    const response = await fetch(`${this.baseUrl}/auth/login`, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify({ email, password })
    })
    
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Login failed')
    }
    
    return response.json()
  }

  async searchTherapists(zipCode: string, specialty?: string) {
    const params = new URLSearchParams({ zipCode })
    if (specialty) params.append('specialty', specialty)
    
    const response = await fetch(`${this.baseUrl}/therapists/search?${params}`, {
      headers: this.headers
    })
    
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Search failed')
    }
    
    return response.json()
  }

  async getTherapistProfile(id: string) {
    const response = await fetch(`${this.baseUrl}/therapist/profile/${id}`, {
      headers: this.headers
    })
    
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to fetch profile')
    }
    
    return response.json()
  }

  async getPlatformStats() {
    const response = await fetch(`${this.baseUrl}/stats`, {
      headers: this.headers
    })
    
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to fetch stats')
    }
    
    return response.json()
  }
}

export const api = new AzenCareAPI()