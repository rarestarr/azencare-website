import { Html, Head, Main, NextScript } from 'next/document'

export default function Document() {
  return (
    <Html lang="en">
      <Head>
        <meta name="description" content="AzenCare - Connecting Therapists to Clients, Instantly. Professional healthcare platform for OT, PT, and SLP services." />
        <meta name="keywords" content="occupational therapy, physical therapy, speech language pathology, healthcare, therapy services" />
        <meta name="author" content="Alexander Azenabor, OTR/L" />
        <meta property="og:title" content="AzenCare - Connecting Therapists to Clients" />
        <meta property="og:description" content="Revolutionary healthcare platform connecting licensed therapists with families in need of therapy services." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://azencare.com" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="AzenCare - Healthcare Platform" />
        <meta name="twitter:description" content="Connecting Therapists to Clients, Instantly" />
        <link rel="icon" href="/favicon.ico" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </Head>
      <body>
        <Main />
        <NextScript />
      </body>
    </Html>
  )
}