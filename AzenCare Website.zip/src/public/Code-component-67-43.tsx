User-agent: *
Allow: /

Sitemap: https://azencare.com/sitemap.xml