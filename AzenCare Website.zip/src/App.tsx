import React from 'react';
import { Header } from './components/Header';
import { CleanHero } from './components/CleanHero';
import { TherapistSection } from './components/TherapistSection';
import { InvestorSection } from './components/InvestorSection';
import { GrantsPartnerships } from './components/GrantsPartnerships';
import { AboutUs } from './components/AboutUs';
import { TrustCompliance } from './components/TrustCompliance';
import { ContactOutreach } from './components/ContactOutreach';
import { Footer } from './components/Footer';
import { Modal } from './components/Modal';
import { TherapistRegistrationForm } from './components/TherapistRegistrationForm';

export default function App() {
  const [showTherapistModal, setShowTherapistModal] = React.useState(false);

  const handleTherapistSignupClick = () => {
    setShowTherapistModal(true);
  };

  const handleCloseModal = () => {
    setShowTherapistModal(false);
  };

  const handleRegistrationSuccess = () => {
    // Could show a success message or redirect
    console.log('Therapist registration successful!');
  };

  const handleLearnMoreClick = () => {
    // Scroll to about section
    document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white">
      <Header onTherapistSignupClick={handleTherapistSignupClick} />
      <main>
        <CleanHero 
          onTherapistSignupClick={handleTherapistSignupClick}
          onLearnMoreClick={handleLearnMoreClick}
        />
        <TherapistSection onSignUpClick={handleTherapistSignupClick} />
        <InvestorSection />
        <GrantsPartnerships />
        <AboutUs />
        <TrustCompliance />
        <ContactOutreach />
      </main>
      <Footer />
      
      {/* Therapist Registration Modal */}
      <Modal isOpen={showTherapistModal} onClose={handleCloseModal}>
        <TherapistRegistrationForm 
          onClose={handleCloseModal}
          onSuccess={handleRegistrationSuccess}
        />
      </Modal>
    </div>
  );
}