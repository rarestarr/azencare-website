import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Users, 
  FileText, 
  Shield, 
  DollarSign, 
  Search, 
  Calendar, 
  CheckCircle,
  ArrowRight,
  Clock,
  UserCheck,
  CreditCard
} from 'lucide-react';

interface TherapistSectionProps {
  onSignUpClick: () => void;
}

export function TherapistSection({ onSignUpClick }: TherapistSectionProps) {
  const benefits = [
    {
      icon: FileText,
      title: "Less Admin Work",
      description: "Automated scheduling, patient intake, and documentation reduce paperwork by 60%",
      color: "blue"
    },
    {
      icon: Users,
      title: "More Clients",
      description: "Connect with patients actively seeking your specific therapy expertise in your area",
      color: "teal"
    },
    {
      icon: Shield,
      title: "HIPAA-Compliant Platform",
      description: "Built-in privacy protection and secure communications keep patient data safe",
      color: "green"
    },
    {
      icon: DollarSign,
      title: "Fast Payouts",
      description: "Get paid within 2-3 business days through secure Stripe integration",
      color: "purple"
    }
  ];

  const processSteps = [
    {
      icon: Search,
      title: "Search",
      description: "Patients find you based on location, specialty, and availability",
      step: "1"
    },
    {
      icon: Calendar,
      title: "Book",
      description: "Instant booking with your real-time schedule integration",
      step: "2"
    },
    {
      icon: UserCheck,
      title: "Session",
      description: "Conduct therapy sessions with built-in documentation tools",
      step: "3"
    },
    {
      icon: CreditCard,
      title: "Payment",
      description: "Automatic payment processing and direct deposit to your account",
      step: "4"
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: "bg-blue-100 text-blue-600 border-blue-200",
      teal: "bg-teal-100 text-teal-600 border-teal-200", 
      green: "bg-green-100 text-green-600 border-green-200",
      purple: "bg-purple-100 text-purple-600 border-purple-200"
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <section id="therapists" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge className="bg-blue-100 text-blue-700 border-blue-200 mb-6">
            <Users className="w-4 h-4 mr-2" />
            For Therapists
          </Badge>
          
          <h2 className="text-4xl lg:text-5xl text-gray-900 mb-6">
            Join Our Founding Therapist Network
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Be among the first therapists to experience less administrative burden, 
            more meaningful client connections, and faster payments.
          </p>

          <div className="inline-flex items-center gap-2 bg-teal-50 border border-teal-200 rounded-full px-6 py-3">
            <Clock className="w-5 h-5 text-teal-600" />
            <span className="text-teal-700 font-medium">Early Access: Join now and be part of our founding network</span>
          </div>
        </div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {benefits.map((benefit, index) => (
            <Card key={index} className={`border-2 hover:shadow-lg transition-all hover:scale-105 ${getColorClasses(benefit.color).replace('text-', 'border-').replace('-600', '-200')}`}>
              <CardHeader className="text-center pb-4">
                <div className={`w-16 h-16 mx-auto rounded-2xl flex items-center justify-center mb-4 ${getColorClasses(benefit.color).replace('border-', 'bg-').replace('-200', '-100')}`}>
                  <benefit.icon className={`w-8 h-8 ${getColorClasses(benefit.color).split(' ')[1]}`} />
                </div>
                <CardTitle className="text-xl">{benefit.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center">{benefit.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Process Flow */}
        <div className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-3xl p-8 lg:p-12 mb-16">
          <div className="text-center mb-12">
            <h3 className="text-3xl text-gray-900 mb-4">
              How AzenCare Works for You
            </h3>
            <p className="text-lg text-gray-600">
              Simple workflow that puts you in control while reducing administrative overhead
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {processSteps.map((step, index) => (
              <div key={index} className="text-center relative">
                <div className="relative mb-6">
                  <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto shadow-lg border-4 border-blue-100">
                    <step.icon className="w-8 h-8 text-blue-600" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                    {step.step}
                  </div>
                </div>
                
                <h4 className="text-xl text-gray-900 mb-2">{step.title}</h4>
                <p className="text-gray-600">{step.description}</p>
                
                {/* Connector Arrow */}
                {index < processSteps.length - 1 && (
                  <div className="hidden lg:block absolute top-10 -right-4 text-gray-300">
                    <ArrowRight className="w-8 h-8" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Sign-Up CTA */}
        <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-3xl p-8 lg:p-12 text-white text-center">
          <div className="max-w-3xl mx-auto">
            <h3 className="text-3xl lg:text-4xl mb-4">
              Ready to Transform Your Practice?
            </h3>
            
            <p className="text-xl text-blue-100 mb-8">
              Join 150+ therapists who've already signed up for early access. 
              Simple sign-up process with email and license verification.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <div className="flex items-center gap-3">
                <CheckCircle className="w-6 h-6 text-green-300" />
                <span className="text-blue-100">No setup fees</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="w-6 h-6 text-green-300" />
                <span className="text-blue-100">5-minute setup</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="w-6 h-6 text-green-300" />
                <span className="text-blue-100">Cancel anytime</span>
              </div>
            </div>

            <Button 
              onClick={onSignUpClick}
              size="lg" 
              className="h-16 px-12 text-xl bg-white text-blue-600 hover:bg-blue-50"
            >
              Sign Up as a Therapist
              <ArrowRight className="ml-3 h-6 w-6" />
            </Button>
            
            <p className="text-sm text-blue-200 mt-4">
              Join our founding therapist network • Free during beta
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}