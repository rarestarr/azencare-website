import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { ArrowRight, Heart, Brain, Zap } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function Services() {
  const services = [
    {
      id: 'physical-therapy',
      title: 'Physical Therapy',
      description: 'Restore movement and function through evidence-based treatments',
      icon: Zap,
      color: 'blue',
      image: 'https://images.unsplash.com/photo-1649751361457-01d3a696c7e6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaHlzaWNhbCUyMHRoZXJhcHklMjBzZXNzaW9uJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc1Njc2MzU5MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      features: [
        'Injury Recovery',
        'Pain Management',
        'Mobility Improvement',
        'Strength Training',
        'Post-Surgery Rehabilitation'
      ]
    },
    {
      id: 'occupational-therapy',
      title: 'Occupational Therapy',
      description: 'Enhance daily living skills and independence through personalized care',
      icon: Heart,
      color: 'green',
      image: 'https://images.unsplash.com/photo-1709127347884-a106974ef58d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvY2N1cGF0aW9uYWwlMjB0aGVyYXB5JTIwY2hpbGR8ZW58MXx8fHwxNzU2NzYzNTkwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      features: [
        'Daily Living Skills',
        'Fine Motor Development',
        'Sensory Integration',
        'Workplace Adaptation',
        'Pediatric Development'
      ]
    },
    {
      id: 'speech-therapy',
      title: 'Speech-Language Pathology',
      description: 'Improve communication, swallowing, and cognitive skills',
      icon: Brain,
      color: 'purple',
      image: 'https://images.unsplash.com/photo-1698373890183-ae3943362fda?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcGVlY2glMjB0aGVyYXB5JTIwc2Vzc2lvbnxlbnwxfHx8fDE3NTY3NjM1OTF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      features: [
        'Speech Disorders',
        'Language Development',
        'Swallowing Therapy',
        'Voice Therapy',
        'Cognitive Communication'
      ]
    }
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case 'blue':
        return 'text-blue-600 bg-blue-100';
      case 'green':
        return 'text-cyan-600 bg-cyan-100';
      case 'purple':
        return 'text-indigo-600 bg-indigo-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <section id="services" className="relative py-20 bg-gray-50">
      {/* Subtle overlay for content contrast */}
      <div className="absolute inset-0 bg-blue-50/30 bg-[rgba(0,117,244,0.59)]"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Expert Therapy Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our network of licensed therapists provides comprehensive care across three 
            essential therapy disciplines to help you achieve your health goals.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => {
            const IconComponent = service.icon;
            return (
              <Card key={service.id} className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
                <div className="relative h-48">
                  <ImageWithFallback
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                  <div className={`absolute top-4 left-4 w-12 h-12 rounded-full ${getColorClasses(service.color)} flex items-center justify-center`}>
                    <IconComponent className="h-6 w-6" />
                  </div>
                </div>
                
                <CardHeader>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                  <CardDescription className="text-base">
                    {service.description}
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <ul className="space-y-2">
                    {service.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm text-gray-600">
                        <div className="w-1.5 h-1.5 bg-gray-400 rounded-full mr-3"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                  
                  <Button variant="outline" className="w-full group">
                    Find {service.title.split(' ')[0]} Therapists
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}