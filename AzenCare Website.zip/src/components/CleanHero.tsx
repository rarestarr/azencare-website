import image_8104b865fcdf51d9959c3d242b9af7915e642ca7 from 'figma:asset/8104b865fcdf51d9959c3d242b9af7915e642ca7.png';
import React from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ArrowRight, Users, Shield, Zap } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface CleanHeroProps {
  onTherapistSignupClick: () => void;
  onLearnMoreClick: () => void;
}

export function CleanHero({ onTherapistSignupClick, onLearnMoreClick }: CleanHeroProps) {
  return (
    <section className="relative bg-gradient-to-b from-blue-50 to-white py-16 lg:py-24 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(37,99,235,0.05),transparent_50%)]"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          
          {/* Hero Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <Badge className="bg-teal-100 text-teal-700 border-teal-200 w-fit">
                <Zap className="w-3 h-3 mr-2" />
                HIPAA-Compliant Platform
              </Badge>
              
              <h1 className="text-4xl lg:text-5xl xl:text-6xl text-gray-900 leading-tight">
                Connecting Therapists to Clients,{' '}
                <span className="text-blue-600">Instantly.</span>
              </h1>
              
              <p className="text-xl lg:text-2xl text-gray-600 leading-relaxed max-w-2xl">
                AzenCare™ streamlines therapy access for patients while helping therapists 
                grow their practice with less administrative burden.
              </p>
            </div>

            {/* Key Benefits */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 py-6">
              <div className="flex items-center gap-3 p-4 bg-white rounded-lg border border-gray-100 shadow-sm">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Users className="w-4 h-4 text-blue-600" />
                </div>
                <span className="text-gray-700 text-sm">More Clients</span>
              </div>
              
              <div className="flex items-center gap-3 p-4 bg-white rounded-lg border border-gray-100 shadow-sm">
                <div className="w-8 h-8 bg-teal-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Zap className="w-4 h-4 text-teal-600" />
                </div>
                <span className="text-gray-700 text-sm">Less Admin</span>
              </div>
              
              <div className="flex items-center gap-3 p-4 bg-white rounded-lg border border-gray-100 shadow-sm">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Shield className="w-4 h-4 text-green-600" />
                </div>
                <span className="text-gray-700 text-sm">Fast Payouts</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button 
                onClick={onTherapistSignupClick}
                size="lg" 
                className="h-14 px-8 text-lg bg-blue-600 hover:bg-blue-700"
              >
                Sign Up as a Therapist
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              
              <Button 
                onClick={onLearnMoreClick}
                variant="outline" 
                size="lg" 
                className="h-14 px-8 text-lg border-blue-200 text-blue-600 hover:bg-blue-50"
              >
                Learn About AzenCare
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="pt-6 border-t border-gray-200">
              <div className="flex flex-wrap items-center gap-6 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-green-600" />
                  <span>HIPAA Compliant</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>AzenCare™ LLC</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span>Secure Payments</span>
                </div>
              </div>
            </div>
          </div>

          {/* Hero Image */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden bg-white shadow-2xl border border-gray-200">
              <ImageWithFallback
                src={image_8104b865fcdf51d9959c3d242b9af7915e642ca7}
                alt="Healthcare technology professional using AzenCare platform"
                className="w-full h-80 lg:h-96 object-cover"
              />
              
              {/* Overlay Stats */}
              <div className="absolute bottom-4 left-4 right-4">
                <div className="bg-white/95 backdrop-blur-sm rounded-lg p-4 border border-gray-200">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-2xl text-blue-600">150+</div>
                      <div className="text-xs text-gray-600">Therapists</div>
                    </div>
                    <div>
                      <div className="text-2xl text-teal-600">5 min</div>
                      <div className="text-xs text-gray-600">Avg Setup</div>
                    </div>
                    <div>
                      <div className="text-2xl text-green-600">24/7</div>
                      <div className="text-xs text-gray-600">Support</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Floating Elements */}
            <div className="absolute -top-4 -right-4 bg-teal-100 rounded-full p-3">
              <Users className="w-6 h-6 text-teal-600" />
            </div>
            
            <div className="absolute -bottom-4 -left-4 bg-blue-100 rounded-full p-3">
              <Shield className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}