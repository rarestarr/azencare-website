import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { PlatformStats } from './PlatformStats';
import { 
  TrendingUp, 
  Target, 
  Zap, 
  Users, 
  Globe,
  ArrowRight,
  FileText,
  Shield,
  BarChart3,
  CheckCircle,
  Briefcase
} from 'lucide-react';

export function InvestorSection() {
  const [showInvestorForm, setShowInvestorForm] = React.useState(false);

  const visionPoints = [
    "Eliminate therapy access barriers through intelligent matching technology",
    "Empower therapists with tools that reduce admin burden by 60%", 
    "Create the first comprehensive therapy marketplace serving underserved markets",
    "Build sustainable healthcare infrastructure that scales nationwide"
  ];

  const marketData = [
    { label: "Total Addressable Market", value: "$2.1B", subtitle: "US therapy services" },
    { label: "Market Growth Rate", value: "15%", subtitle: "Annual growth" },
    { label: "Digital Adoption Gap", value: "73%", subtitle: "Still using outdated systems" },
    { label: "Target Market Share", value: "2-5%", subtitle: "Within 5 years" }
  ];

  const advantages = [
    {
      title: "Real-Time Matching Algorithm",
      description: "AI-powered system matches patients with ideal therapists instantly",
      icon: Zap
    },
    {
      title: "HIPAA-Compliant Infrastructure",
      description: "Built from ground up with healthcare privacy and security requirements",
      icon: Shield
    },
    {
      title: "Underserved Market Focus",
      description: "Targeting geographic areas where traditional platforms have limited presence",
      icon: Target
    },
    {
      title: "Integrated Payment System",
      description: "Streamlined billing and payments through Stripe integration",
      icon: BarChart3
    }
  ];

  const roadmapPhases = [
    {
      phase: "Prototype",
      status: "complete",
      description: "Figma prototype validated with user testing",
      timeline: "Q3 2025"
    },
    {
      phase: "MVP Development",
      status: "current", 
      description: "Supabase backend complete, frontend development in progress",
      timeline: "Q4 2025"
    },
    {
      phase: "Beta Launch",
      status: "upcoming",
      description: "Limited market launch with 50+ therapists and 500+ patients",
      timeline: "Q1 2026"
    },
    {
      phase: "Market Scaling",
      status: "planned",
      description: "Expand to 5 major metro areas with 500+ therapists",
      timeline: "Q2-Q3 2026"
    }
  ];

  return (
    <section id="investors" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge className="bg-green-100 text-green-700 border-green-200 mb-6">
            <Briefcase className="w-4 h-4 mr-2" />
            Investment Opportunity
          </Badge>
          
          <h2 className="text-4xl lg:text-5xl text-gray-900 mb-6">
            Series A Investment Snapshot
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            AzenCare is revolutionizing therapy access with proven technology, 
            strong market validation, and a clear path to profitability.
          </p>
        </div>

        {/* Platform Statistics */}
        <div className="mb-16">
          <PlatformStats />
        </div>

        {/* Vision & Mission */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <Card className="border-blue-200 bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-2">
                <Target className="w-6 h-6 text-blue-600" />
                Our Vision & Mission
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {visionPoints.map((point, index) => (
                <div key={index} className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <p className="text-gray-700">{point}</p>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-green-200 bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-2">
                <Globe className="w-6 h-6 text-green-600" />
                Market Opportunity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-6">
                {marketData.map((data, index) => (
                  <div key={index} className="text-center">
                    <div className="text-3xl text-green-600 mb-1">{data.value}</div>
                    <div className="font-medium text-gray-900 text-sm mb-1">{data.label}</div>
                    <div className="text-xs text-gray-600">{data.subtitle}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Competitive Advantages */}
        <div className="mb-16">
          <h3 className="text-3xl text-gray-900 mb-8 text-center">
            Why AzenCare is Different
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {advantages.map((advantage, index) => (
              <Card key={index} className="border-teal-200 bg-white hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
                      <advantage.icon className="w-5 h-5 text-teal-600" />
                    </div>
                    <CardTitle className="text-lg">{advantage.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{advantage.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Development Roadmap */}
        <div className="mb-16">
          <h3 className="text-3xl text-gray-900 mb-8 text-center">
            Development Roadmap
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {roadmapPhases.map((phase, index) => (
              <Card key={index} className={`text-center ${
                phase.status === 'complete' ? 'border-green-200 bg-green-50' :
                phase.status === 'current' ? 'border-blue-200 bg-blue-50' :
                'border-gray-200 bg-gray-50'
              }`}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <Badge className={
                      phase.status === 'complete' ? 'bg-green-100 text-green-700' :
                      phase.status === 'current' ? 'bg-blue-100 text-blue-700' :
                      'bg-gray-100 text-gray-700'
                    }>
                      {phase.status === 'complete' ? '✓ Complete' :
                       phase.status === 'current' ? '⚡ Current' :
                       phase.status === 'upcoming' ? '🚀 Next' : '📋 Planned'}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl">{phase.phase}</CardTitle>
                  <p className="text-sm text-gray-600">{phase.timeline}</p>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-700">{phase.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Investment CTA */}
        <Card className="bg-gradient-to-r from-blue-600 to-indigo-700 border-none text-white">
          <CardContent className="p-8 lg:p-12 text-center">
            <h3 className="text-3xl lg:text-4xl mb-4">
              Join Our Series A Round
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
              <div>
                <div className="text-3xl mb-2">$2.5M</div>
                <div className="text-blue-200">Seeking Investment</div>
              </div>
              <div>
                <div className="text-3xl mb-2">18 mo</div>
                <div className="text-blue-200">To Profitability</div>
              </div>
              <div>
                <div className="text-3xl mb-2">8-12x</div>
                <div className="text-blue-200">Projected ROI</div>
              </div>
            </div>

            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Ready to revolutionize healthcare access? Request our comprehensive 
              investor deck with detailed financials, market analysis, and growth projections.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg"
                className="h-14 px-8 bg-white text-blue-600 hover:bg-blue-50"
                onClick={() => setShowInvestorForm(true)}
              >
                <FileText className="mr-2 h-5 w-5" />
                Request Investor Deck
              </Button>
              
              <Button 
                variant="outline"
                size="lg"
                className="h-14 px-8 border-white text-white hover:bg-white/10"
              >
                Schedule Meeting
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>

            <p className="text-sm text-blue-200 mt-6">
              All investor materials include NDA protection • AzenCare™ LLC
            </p>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}