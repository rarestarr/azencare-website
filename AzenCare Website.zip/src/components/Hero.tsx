import React from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Search, ArrowRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import heroImage from 'figma:asset/8104b865fcdf51d9959c3d242b9af7915e642ca7.png';

export function Hero() {
  const [zipCode, setZipCode] = React.useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Scroll to therapists section
    document.getElementById('therapists')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative bg-gradient-to-b from-blue-50 to-white py-20">
      {/* Subtle overlay for content contrast */}
      <div className="absolute inset-0 bg-white/20 backdrop-blur-[1px] bg-[rgba(4,135,254,0.64)]"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Hero Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 leading-tight">
                Connect with Expert Therapists in Your Area
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Find qualified Occupational, Physical, and Speech-Language Pathologists 
                near you. Quality therapy care, personalized to your needs.
              </p>
            </div>

            {/* Search Form */}
            <form onSubmit={handleSearch} className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Input
                    type="text"
                    placeholder="Enter your zip code"
                    value={zipCode}
                    onChange={(e) => setZipCode(e.target.value)}
                    className="pl-12 h-14 text-lg bg-white"
                  />
                  <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                </div>
                <Button type="submit" size="lg" className="h-14 px-8">
                  Find Therapists
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </div>
            </form>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">500+</div>
                <div className="text-gray-600">Therapists</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">50+</div>
                <div className="text-gray-600">Cities</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">1000+</div>
                <div className="text-gray-600">Happy Clients</div>
              </div>
            </div>
          </div>

          {/* Hero Image */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src={heroImage}
                alt="Multi-generational therapy services including physical therapy, occupational therapy, and speech-language pathology sessions"
                className="w-full h-96 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
            </div>
            
            {/* Floating Cards */}
            <div className="absolute -bottom-6 -left-6 bg-white rounded-[65px] shadow-lg max-w-xs px-[4px] py-[6px]">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 font-semibold">PT</span>
                </div>
                <div>
                  <div className="font-semibold text-[12px]">Physical Therapy</div>
                  <div className="text-sm text-gray-600 text-[10px]">Recovery & Mobility</div>
                </div>
              </div>
            </div>
            
            <div className="absolute -top-6 -left-6 bg-white rounded-[65px] shadow-lg max-w-xs px-[4px] py-[6px]">
              <div className="flex items-center space-x-3 rounded-[20px]">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-green-600 font-semibold">OT</span>
                </div>
                <div>
                  <div className="font-semibold text-[12px]">Occupational Therapy</div>
                  <div className="text-sm text-gray-600 text-[10px]">Daily Life Skills</div>
                </div>
              </div>
            </div>
            
            <div className="absolute -bottom-6 -right-6 bg-white rounded-[65px] shadow-lg max-w-xs px-[4px] py-[6px] mx-[-14px] my-[0px]">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <span className="text-purple-600 font-semibold">SLP</span>
                </div>
                <div>
                  <div className="font-semibold text-[12px]">Speech-Language Pathology</div>
                  <div className="text-sm text-gray-600 text-[10px]">Communication & Speech</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}