import React from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ArrowLeft, Users, Award, MapPin, Clock, Star, Gift, Zap, Heart } from 'lucide-react';

interface TherapistSignupProps {
  onBack: () => void;
}

export function TherapistSignup({ onBack }: TherapistSignupProps) {
  const [formData, setFormData] = React.useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    licenseState: '',
    practiceLocation: '',
    specialty: '',
    acceptTerms: false,
    acceptNotifications: true
  });

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Therapist early signup data:', formData);
    // Show success message
    alert('🎉 Welcome to AzenCare! You\'re now part of our early therapist network. We\'ll be in touch soon with updates!');
  };

  const specialties = [
    { value: 'OT', label: 'Occupational Therapy (OT)' },
    { value: 'PT', label: 'Physical Therapy (PT)' },
    { value: 'SLP', label: 'Speech-Language Pathology (SLP)' }
  ];

  const states = [
    'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware', 
    'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 
    'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 
    'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', 
    'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 
    'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 
    'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'
  ];

  return (
    <section className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 py-8">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <Button 
            variant="ghost" 
            onClick={onBack}
            className="mb-4 hover:bg-blue-50"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
          
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Badge className="bg-green-100 text-green-700 border-green-200">
                <Gift className="w-3 h-3 mr-1" />
                Early Access
              </Badge>
              <Badge className="bg-purple-100 text-purple-700 border-purple-200">
                <Zap className="w-3 h-3 mr-1" />
                Free to Join
              </Badge>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">Join AzenCare Early!</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Be among the first therapists to connect with clients in your area. 
              Simple signup, no commitments - just opportunities.
            </p>
          </div>
        </div>

        {/* Benefits Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="text-center p-6 border-blue-100 bg-blue-50/50 hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Early Client Access</h3>
            <p className="text-sm text-gray-600">Get priority access to clients seeking therapy in your area</p>
          </Card>
          
          <Card className="text-center p-6 border-green-100 bg-green-50/50 hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">No Fees</h3>
            <p className="text-sm text-gray-600">Join for free as an early member - no platform fees or hidden costs</p>
          </Card>
          
          <Card className="text-center p-6 border-purple-100 bg-purple-50/50 hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Star className="h-6 w-6 text-purple-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Founding Member</h3>
            <p className="text-sm text-gray-600">Shape our platform and enjoy exclusive founding member benefits</p>
          </Card>
        </div>

        {/* Simplified Signup Form */}
        <Card className="bg-white/80 backdrop-blur-sm border-gray-200 shadow-xl">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2 text-2xl">
              <Star className="h-6 w-6 text-primary" />
              Reserve Your Spot
            </CardTitle>
            <CardDescription className="text-lg">
              Quick signup - takes less than 2 minutes! ⏱️
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Personal Information */}
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name *</Label>
                    <Input
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) => handleInputChange('firstName', e.target.value)}
                      required
                      className="bg-white h-12"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name *</Label>
                    <Input
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) => handleInputChange('lastName', e.target.value)}
                      required
                      className="bg-white h-12"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      required
                      className="bg-white h-12"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number <span className="text-gray-500">(Optional)</span></Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      className="bg-white h-12"
                      placeholder="For priority contact"
                    />
                  </div>
                </div>
              </div>

              {/* Professional Information */}
              <div className="space-y-4 bg-blue-50/50 p-6 rounded-lg">
                <h3 className="font-semibold text-gray-900 text-lg">Professional Details</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="specialty">Your Specialty *</Label>
                    <Select onValueChange={(value) => handleInputChange('specialty', value)} required>
                      <SelectTrigger className="bg-white h-12">
                        <SelectValue placeholder="Select your specialty" />
                      </SelectTrigger>
                      <SelectContent>
                        {specialties.map(specialty => (
                          <SelectItem key={specialty.value} value={specialty.value}>
                            {specialty.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="licenseState">License State *</Label>
                    <Select onValueChange={(value) => handleInputChange('licenseState', value)} required>
                      <SelectTrigger className="bg-white h-12">
                        <SelectValue placeholder="Where are you licensed?" />
                      </SelectTrigger>
                      <SelectContent className="max-h-48">
                        {states.map(state => (
                          <SelectItem key={state} value={state}>
                            {state}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="practiceLocation">Practice Location *</Label>
                  <Input
                    id="practiceLocation"
                    value={formData.practiceLocation}
                    onChange={(e) => handleInputChange('practiceLocation', e.target.value)}
                    required
                    className="bg-white h-12"
                    placeholder="e.g., New York, NY or ZIP code 11374"
                  />
                  <p className="text-sm text-gray-500">City, state or ZIP code where you practice</p>
                </div>
              </div>

              {/* Terms */}
              <div className="space-y-3 bg-gray-50 p-4 rounded-lg">
                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="acceptTerms"
                    checked={formData.acceptTerms}
                    onCheckedChange={(checked) => handleInputChange('acceptTerms', checked as boolean)}
                    required
                  />
                  <Label htmlFor="acceptTerms" className="text-sm leading-relaxed">
                    I'm a licensed therapy professional and agree to AzenCare's terms *
                  </Label>
                </div>
                
                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="acceptNotifications"
                    checked={formData.acceptNotifications}
                    onCheckedChange={(checked) => handleInputChange('acceptNotifications', checked as boolean)}
                  />
                  <Label htmlFor="acceptNotifications" className="text-sm leading-relaxed">
                    Send me updates about client matches and platform news 📧
                  </Label>
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-4">
                <Button type="submit" size="lg" className="w-full h-14 text-lg">
                  🚀 Join AzenCare Early Access
                </Button>
                <p className="text-center text-sm text-gray-500 mt-3">
                  Free forever for early members • No commitments • Cancel anytime
                </p>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Footer Note */}
        <div className="mt-8 text-center space-y-3">
          <div className="flex items-center justify-center space-x-6 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4 text-green-600" />
              <span>Instant confirmation</span>
            </div>
            <div className="flex items-center gap-1">
              <Users className="w-4 h-4 text-blue-600" />
              <span>Join 50+ early therapists</span>
            </div>
          </div>
          
          <p className="text-sm text-gray-500">
            Questions? We're here to help at{' '}
            <a href="tel:718-772-2453" className="text-primary hover:underline font-medium">
              (718) 772-2453
            </a>
          </p>
        </div>
      </div>
    </section>
  );
}