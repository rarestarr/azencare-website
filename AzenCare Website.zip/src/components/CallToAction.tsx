import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  Users, 
  TrendingUp, 
  HandHeart,
  ArrowRight,
  Mail,
  Phone,
  Calendar,
  Star,
  Target,
  Briefcase,
  MapPin
} from 'lucide-react';

interface CallToActionProps {
  onTherapistSignupClick: () => void;
}

export function CallToAction({ onTherapistSignupClick }: CallToActionProps) {
  const audienceCards = [
    {
      title: "Therapists",
      subtitle: "Join Our Network",
      icon: Users,
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600",
      borderColor: "border-blue-200",
      bgColor: "bg-blue-50/50",
      description: "Be part of the platform revolutionizing how patients find and connect with qualified therapists.",
      benefits: [
        "Early adopter advantages",
        "Increased patient flow",
        "No platform fees initially",
        "Professional growth opportunities"
      ],
      cta: "Join Early Access",
      ctaAction: onTherapistSignupClick,
      badge: "150+ Already Joined"
    },
    {
      title: "Investors",
      subtitle: "Series A Opportunity",
      icon: TrendingUp,
      iconBg: "bg-green-100",
      iconColor: "text-green-600",
      borderColor: "border-green-200",
      bgColor: "bg-green-50/50",
      description: "Invest in the future of healthcare accessibility. Join us in solving a $2.1B market opportunity.",
      benefits: [
        "$2.5M Series A round",
        "8-12x projected ROI",
        "Scalable technology platform",
        "Experienced healthcare team"
      ],
      cta: "Request Investor Deck",
      ctaAction: () => console.log('Investor deck requested'),
      badge: "Series A Open"
    },
    {
      title: "Partners",
      subtitle: "Healthcare Collaboration",
      icon: HandHeart,
      iconBg: "bg-purple-100",
      iconColor: "text-purple-600",
      borderColor: "border-purple-200",
      bgColor: "bg-purple-50/50",
      description: "Partner with AzenCare to improve patient outcomes and streamline therapy access in your organization.",
      benefits: [
        "Improved patient satisfaction",
        "Reduced wait times",
        "Better care coordination",
        "Custom integration support"
      ],
      cta: "Explore Partnership",
      ctaAction: () => console.log('Partnership inquiry'),
      badge: "Enterprise Ready"
    }
  ];

  const contactInfo = [
    {
      type: "General Inquiries",
      value: "(718) 772-2453",
      icon: Phone,
      action: "tel:718-772-2453"
    },
    {
      type: "Business Email",
      value: "hello@azencare.com",
      icon: Mail,
      action: "mailto:hello@azencare.com"
    },
    {
      type: "Schedule Meeting",
      value: "Book a Call",
      icon: Calendar,
      action: "#"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 via-white to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge className="bg-primary/10 text-primary border-primary/20 mb-4">
            <Star className="w-4 h-4 mr-2" />
            Get Involved
          </Badge>
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Join the Healthcare Revolution
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Whether you're a therapist looking to grow your practice, an investor seeking opportunities, 
            or a healthcare organization wanting to improve patient access—we want to work with you.
          </p>
        </div>

        {/* Audience-Specific CTAs */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {audienceCards.map((card, index) => (
            <Card 
              key={index} 
              className={`${card.borderColor} ${card.bgColor} hover:shadow-xl transition-all hover:scale-105 relative overflow-hidden`}
            >
              <CardHeader className="relative">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 ${card.iconBg} rounded-lg flex items-center justify-center`}>
                    <card.icon className={`w-6 h-6 ${card.iconColor}`} />
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {card.badge}
                  </Badge>
                </div>
                <CardTitle className="text-2xl">{card.title}</CardTitle>
                <p className="text-sm text-gray-600 font-medium">{card.subtitle}</p>
              </CardHeader>
              
              <CardContent className="space-y-6">
                <p className="text-gray-600">{card.description}</p>
                
                <div className="space-y-2">
                  {card.benefits.map((benefit, benefitIndex) => (
                    <div key={benefitIndex} className="flex items-center gap-2">
                      <div className={`w-2 h-2 ${card.iconColor.replace('text-', 'bg-')} rounded-full`}></div>
                      <span className="text-sm text-gray-700">{benefit}</span>
                    </div>
                  ))}
                </div>
                
                <Button 
                  onClick={card.ctaAction}
                  className="w-full"
                  size="lg"
                >
                  {card.cta}
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Contact Information */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Ready to Get Started?
              </h3>
              <p className="text-gray-600 mb-6">
                AzenCare LLC is headquartered in New York and ready to discuss how we can work together 
                to improve therapy access for everyone.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center gap-3 text-gray-700">
                  <MapPin className="w-5 h-5 text-primary" />
                  <span>New York, NY 11374</span>
                </div>
                
                {contactInfo.map((contact, index) => (
                  <a
                    key={index}
                    href={contact.action}
                    className="flex items-center gap-3 text-gray-700 hover:text-primary transition-colors"
                  >
                    <contact.icon className="w-5 h-5 text-primary" />
                    <span>{contact.value}</span>
                  </a>
                ))}
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl p-8 text-white">
              <div className="flex items-center gap-2 mb-4">
                <Briefcase className="w-6 h-6" />
                <h4 className="text-xl font-bold">Business Inquiries</h4>
              </div>
              
              <p className="text-blue-100 mb-6">
                Interested in strategic partnerships, investment opportunities, or enterprise solutions? 
                Let's discuss how AzenCare can work with your organization.
              </p>
              
              <div className="space-y-3">
                <Button 
                  size="lg" 
                  className="w-full bg-white text-blue-600 hover:bg-blue-50"
                  onClick={() => window.open('mailto:hello@azencare.com?subject=Business Inquiry', '_blank')}
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Send Business Inquiry
                </Button>
                
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="w-full border-white text-white hover:bg-white/10"
                  onClick={() => console.log('Calendar booking')}
                >
                  <Calendar className="mr-2 h-5 w-5" />
                  Schedule Strategy Call
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Final Message */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">
              Together, We Can Transform Healthcare Access
            </h3>
            <p className="text-blue-100 max-w-2xl mx-auto">
              AzenCare is more than a platform—it's a movement to make quality therapy accessible to everyone. 
              Join us in building the future of healthcare.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}