import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  TrendingUp, 
  DollarSign, 
  Users, 
  MapPin,
  BarChart3,
  Target,
  Zap,
  Award,
  Globe,
  ArrowUpRight
} from 'lucide-react';

export function MarketOpportunity() {
  const marketStats = [
    {
      title: "Total Addressable Market",
      value: "$2.1B",
      growth: "+15% annually",
      icon: Globe,
      description: "US therapy services market size"
    },
    {
      title: "Digital Health Growth",
      value: "300%",
      growth: "Since 2020",
      icon: TrendingUp,
      description: "Increase in telehealth adoption"
    },
    {
      title: "Therapy Demand",
      value: "89%",
      growth: "+23% YoY",
      icon: Users,
      description: "Americans report therapy access challenges"
    },
    {
      title: "Market Gap",
      value: "$480M",
      growth: "Opportunity",
      icon: Target,
      description: "Unmet demand in therapy matching"
    }
  ];

  const competitiveAdvantages = [
    {
      title: "Real-Time Matching",
      description: "AI-powered algorithms match patients with therapists instantly based on multiple criteria",
      icon: Zap,
      impact: "90% faster than traditional methods"
    },
    {
      title: "Verified Network",
      description: "Licensed professionals only, with credential verification and continuous quality monitoring",
      icon: Award,
      impact: "100% licensed therapist guarantee"
    },
    {
      title: "Geographic Coverage",
      description: "Focus on underserved markets where traditional platforms have limited presence",
      icon: MapPin,
      impact: "30% larger addressable market"
    },
    {
      title: "Integrated Experience",
      description: "End-to-end platform from discovery to scheduling to care coordination",
      icon: Target,
      impact: "5x better user retention"
    }
  ];

  const traction = [
    { metric: "Therapist Interest", value: "150+", detail: "Pre-registered therapists" },
    { metric: "Patient Inquiries", value: "300+", detail: "Interested patients in waitlist" },
    { metric: "Geographic Markets", value: "12", detail: "Target cities identified" },
    { metric: "Strategic Partnerships", value: "5", detail: "Healthcare systems interested" }
  ];

  return (
    <section id="opportunity" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge className="bg-green-100 text-green-700 border-green-200 mb-4">
            <BarChart3 className="w-4 h-4 mr-2" />
            Market Opportunity
          </Badge>
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            A $2.1B Market Ready for Disruption
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            The therapy services market is experiencing unprecedented growth, while technology adoption 
            has lagged behind. AzenCare is positioned to capture this massive opportunity.
          </p>
        </div>

        {/* Market Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {marketStats.map((stat, index) => (
            <Card key={index} className="text-center border-green-200 bg-green-50/30 hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <stat.icon className="w-6 h-6 text-green-600" />
                </div>
                <CardTitle className="text-lg">{stat.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600 mb-2">{stat.value}</div>
                <div className="text-sm font-medium text-green-700 mb-2">{stat.growth}</div>
                <p className="text-sm text-gray-600">{stat.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Competitive Advantages */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              Our Competitive Advantages
            </h3>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              AzenCare's unique positioning and technology create multiple moats in the therapy matching space
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {competitiveAdvantages.map((advantage, index) => (
              <Card key={index} className="border-blue-200 bg-blue-50/30 hover:shadow-lg transition-all hover:scale-105">
                <CardHeader>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <advantage.icon className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">{advantage.title}</CardTitle>
                      <Badge variant="secondary" className="bg-blue-100 text-blue-700 mt-1">
                        {advantage.impact}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{advantage.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Traction & Validation */}
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-3xl p-12 mb-16">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              Early Traction & Validation
            </h3>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Strong early indicators validate market demand and our approach to solving therapy access challenges
            </p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {traction.map((item, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-blue-600 mb-2">{item.value}</div>
                <div className="font-semibold text-gray-900 mb-1">{item.metric}</div>
                <div className="text-sm text-gray-600">{item.detail}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Revenue Model */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-3xl font-bold text-gray-900 mb-6">
              Scalable Revenue Model
            </h3>
            <div className="space-y-6">
              <Card className="border-green-200 bg-green-50/50">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-green-600" />
                    <CardTitle className="text-lg">Transaction Fees</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-2">
                    8-12% commission on successful bookings
                  </p>
                  <div className="text-sm text-green-700 font-medium">
                    $1.2M projected revenue at 1,000 monthly bookings
                  </div>
                </CardContent>
              </Card>

              <Card className="border-blue-200 bg-blue-50/50">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-blue-600" />
                    <CardTitle className="text-lg">Subscription Plans</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-2">
                    Premium features for therapists and healthcare systems
                  </p>
                  <div className="text-sm text-blue-700 font-medium">
                    $50-200/month per therapist
                  </div>
                </CardContent>
              </Card>

              <Card className="border-purple-200 bg-purple-50/50">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-purple-600" />
                    <CardTitle className="text-lg">Data & Analytics</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-2">
                    Market insights for healthcare organizations
                  </p>
                  <div className="text-sm text-purple-700 font-medium">
                    $5K-50K enterprise contracts
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="bg-gradient-to-br from-gray-900 to-blue-900 rounded-2xl p-8 text-white">
            <h4 className="text-2xl font-bold mb-6">Investment Opportunity</h4>
            
            <div className="space-y-4 mb-8">
              <div className="flex justify-between items-center border-b border-white/20 pb-2">
                <span>Seeking</span>
                <span className="font-bold">$2.5M Series A</span>
              </div>
              <div className="flex justify-between items-center border-b border-white/20 pb-2">
                <span>Use of Funds</span>
                <span className="font-bold">Development & Launch</span>
              </div>
              <div className="flex justify-between items-center border-b border-white/20 pb-2">
                <span>Timeline</span>
                <span className="font-bold">18 months to profitability</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Projected ROI</span>
                <span className="font-bold text-green-300">8-12x in 5 years</span>
              </div>
            </div>

            <div className="space-y-3">
              <Button 
                size="lg" 
                className="w-full bg-white text-gray-900 hover:bg-gray-100"
              >
                <ArrowUpRight className="mr-2 h-5 w-5" />
                Request Investor Deck
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="w-full border-white text-white hover:bg-white/10"
              >
                Schedule Meeting
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}