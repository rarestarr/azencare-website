import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { 
  User, 
  Phone, 
  CheckCircle,
  AlertCircle,
  Loader2,
  UserPlus
} from 'lucide-react';
import { api } from '../utils/supabase/client';

interface TherapistRegistrationFormProps {
  onClose: () => void;
  onSuccess: () => void;
}

export function TherapistRegistrationForm({ onClose, onSuccess }: TherapistRegistrationFormProps) {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    practiceArea: '',
    phone: ''
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const practiceAreas = [
    { value: 'OT', label: 'Occupational Therapy (OT)' },
    { value: 'PT', label: 'Physical Therapy (PT)' },
    { value: 'SLP', label: 'Speech-Language Pathology (SLP)' }
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError(''); // Clear error when user types
  };

  const validateForm = () => {
    if (!formData.firstName || !formData.lastName) {
      setError('First and last name are required');
      return false;
    }
    
    if (!formData.practiceArea) {
      setError('Please select your area of practice');
      return false;
    }
    
    if (!formData.phone) {
      setError('Phone number is required');
      return false;
    }
    
    // Basic phone validation
    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
    const cleanPhone = formData.phone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setError('Please enter a valid phone number');
      return false;
    }
    
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setLoading(true);
    setError('');
    
    try {
      await api.submitTherapistInterest({
        firstName: formData.firstName,
        lastName: formData.lastName,
        practiceArea: formData.practiceArea,
        phone: formData.phone
      });
      
      setSuccess(true);
      setTimeout(() => {
        onSuccess();
        onClose();
      }, 2500);
      
    } catch (err: any) {
      setError(err.message || 'Submission failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <Card className="w-full max-w-lg mx-auto">
        <CardContent className="p-8 text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <h3 className="text-2xl text-gray-900 mb-2">Thank You!</h3>
          <p className="text-gray-600 mb-4">
            You're now on our early access list. We'll contact you when AzenCare launches in your area.
          </p>
          <Badge className="bg-blue-100 text-blue-700">
            We'll be in touch soon!
          </Badge>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-lg mx-auto">
      <CardHeader className="text-center pb-6">
        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <UserPlus className="w-6 h-6 text-blue-600" />
        </div>
        <CardTitle className="text-2xl text-gray-900">Join Our Early Access List</CardTitle>
        <p className="text-gray-600">Be the first to know when AzenCare launches in your area</p>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {error && (
          <Alert className="border-red-200 bg-red-50">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-700">{error}</AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Name Fields */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="firstName" className="flex items-center gap-2">
                <User className="w-4 h-4" />
                First Name *
              </Label>
              <Input
                id="firstName"
                value={formData.firstName}
                onChange={(e) => handleInputChange('firstName', e.target.value)}
                placeholder="John"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name *</Label>
              <Input
                id="lastName"
                value={formData.lastName}
                onChange={(e) => handleInputChange('lastName', e.target.value)}
                placeholder="Smith"
                required
              />
            </div>
          </div>

          {/* Practice Area */}
          <div className="space-y-2">
            <Label htmlFor="practiceArea">Area of Practice *</Label>
            <Select value={formData.practiceArea} onValueChange={(value) => handleInputChange('practiceArea', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select your area of practice" />
              </SelectTrigger>
              <SelectContent>
                {practiceAreas.map((area) => (
                  <SelectItem key={area.value} value={area.value}>
                    {area.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {/* Phone Number */}
          <div className="space-y-2">
            <Label htmlFor="phone" className="flex items-center gap-2">
              <Phone className="w-4 h-4" />
              Phone Number *
            </Label>
            <Input
              id="phone"
              type="tel"
              value={formData.phone}
              onChange={(e) => handleInputChange('phone', e.target.value)}
              placeholder="(555) 123-4567"
              required
            />
          </div>

          {/* Submit Buttons */}
          <div className="flex flex-col gap-3 pt-4">
            <Button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 h-12"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                'Join Early Access List'
              )}
            </Button>
            
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="w-full"
              disabled={loading}
            >
              Cancel
            </Button>
          </div>
        </form>

        <div className="text-center text-sm text-gray-500">
          No spam, just updates about AzenCare's launch in your area
        </div>
      </CardContent>
    </Card>
  );
}