import React from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ArrowRight, Play, Users, Zap, Target } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function NewHero() {
  const handleWatchDemo = () => {
    // Demo functionality
    console.log('Watch demo clicked');
  };

  const handleJoinTherapists = () => {
    // Navigate to therapist signup
    document.getElementById('therapist-signup')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleInvestorInfo = () => {
    // Navigate to investor section
    document.getElementById('opportunity')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative bg-gradient-to-br from-blue-50 via-white to-indigo-50 py-20 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(59,130,246,0.1),transparent_50%)]"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(99,102,241,0.1),transparent_50%)]"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Hero Content */}
          <div className="space-y-8">
            {/* Status Badge */}
            <div className="flex flex-wrap gap-3">
              <Badge className="bg-green-100 text-green-700 border-green-200 px-4 py-2">
                <Zap className="w-4 h-4 mr-2" />
                MVP Ready • Supabase Backend
              </Badge>
              <Badge className="bg-purple-100 text-purple-700 border-purple-200 px-4 py-2">
                <Target className="w-4 h-4 mr-2" />
                Entering Development Phase
              </Badge>
            </div>

            <div className="space-y-6">
              <h1 className="text-5xl md:text-6xl font-bold text-gray-900 leading-tight">
                Revolutionizing 
                <span className="text-primary"> Therapy Access</span> 
                for Everyone
              </h1>
              
              <p className="text-xl text-gray-600 leading-relaxed max-w-xl">
                AzenCare bridges the critical gap between qualified therapists and patients who need them most. 
                Our platform transforms how therapy services are discovered, accessed, and delivered.
              </p>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-3">The Healthcare Crisis We're Solving:</h3>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                    <span>73% of therapy practices still rely on outdated referral systems</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                    <span>Average wait time for therapy appointments: 4-8 weeks</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                    <span>60% of patients abandon care due to access barriers</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" onClick={handleWatchDemo} className="h-14 px-8 text-lg">
                <Play className="mr-2 h-5 w-5" />
                Watch Platform Demo
              </Button>
              
              <Button 
                variant="outline" 
                size="lg" 
                onClick={handleInvestorInfo}
                className="h-14 px-8 text-lg border-primary text-primary hover:bg-primary hover:text-white"
              >
                Investment Opportunity
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8 border-t border-gray-200">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">$2.1B</div>
                <div className="text-sm text-gray-600">Market Opportunity</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">150+</div>
                <div className="text-sm text-gray-600">Therapists Interested</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">3</div>
                <div className="text-sm text-gray-600">Core Specialties</div>
              </div>
            </div>
          </div>

          {/* Hero Visual */}
          <div className="relative">
            {/* Main Dashboard Preview */}
            <div className="relative bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden">
              <div className="bg-gradient-to-r from-primary to-blue-600 p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                      <Users className="w-5 h-5 text-white" />
                    </div>
                    <div className="text-white">
                      <div className="font-semibold">AzenCare Platform</div>
                      <div className="text-sm opacity-90">MVP Dashboard</div>
                    </div>
                  </div>
                  <Badge className="bg-white/20 text-white border-white/30">
                    Live Prototype
                  </Badge>
                </div>
              </div>
              
              <div className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <span className="font-semibold text-sm">Active Therapists</span>
                    </div>
                    <div className="text-2xl font-bold text-green-700">47</div>
                  </div>
                  
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                      <span className="font-semibold text-sm">Patient Matches</span>
                    </div>
                    <div className="text-2xl font-bold text-blue-700">12</div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-blue-600 font-semibold text-sm">PT</span>
                      </div>
                      <div>
                        <div className="font-semibold text-sm">Dr. Sarah Chen</div>
                        <div className="text-xs text-gray-600">Physical Therapy • NYC</div>
                      </div>
                    </div>
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                        <span className="text-green-600 font-semibold text-sm">OT</span>
                      </div>
                      <div>
                        <div className="font-semibold text-sm">Maria Rodriguez</div>
                        <div className="text-xs text-gray-600">Occupational Therapy • Queens</div>
                      </div>
                    </div>
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                        <span className="text-purple-600 font-semibold text-sm">SLP</span>
                      </div>
                      <div>
                        <div className="font-semibold text-sm">James Wilson</div>
                        <div className="text-xs text-gray-600">Speech Therapy • Brooklyn</div>
                      </div>
                    </div>
                    <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Floating Tech Stack */}
            <div className="absolute -bottom-6 -left-6 bg-white rounded-lg shadow-lg border border-gray-200 p-4 max-w-xs">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="w-4 h-4 text-primary" />
                <span className="font-semibold text-sm">Tech Stack</span>
              </div>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary" className="text-xs">React</Badge>
                <Badge variant="secondary" className="text-xs">Supabase</Badge>
                <Badge variant="secondary" className="text-xs">Figma</Badge>
                <Badge variant="secondary" className="text-xs">TypeScript</Badge>
              </div>
            </div>

            {/* Floating Achievement */}
            <div className="absolute -top-6 -right-6 bg-white rounded-lg shadow-lg border border-gray-200 p-4 max-w-xs">
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-4 h-4 text-green-600" />
                <span className="font-semibold text-sm">Development Ready</span>
              </div>
              <p className="text-xs text-gray-600">
                MVP validated • Backend infrastructure complete • Ready for scaling
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}