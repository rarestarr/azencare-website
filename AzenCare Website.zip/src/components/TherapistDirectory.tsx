import React from 'react';
import { Card, CardContent, CardHeader } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { MapPin, Star, Phone, Mail, Filter } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function TherapistDirectory() {
  const [searchZip, setSearchZip] = React.useState('');
  const [selectedSpecialty, setSelectedSpecialty] = React.useState('all');
  const [showFilters, setShowFilters] = React.useState(false);

  const therapists = [
    {
      id: 1,
      name: 'Dr. Sarah Johnson',
      specialty: 'Physical Therapy',
      specialtyShort: 'PT',
      location: 'Phoenix, AZ 85001',
      distance: '2.3 miles',
      rating: 4.9,
      reviews: 127,
      image: 'https://images.unsplash.com/photo-1632054224659-280be3239aff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBoZWFkc2hvdCUyMGRvY3RvcnxlbnwxfHx8fDE3NTY3NjM2NTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      specializations: ['Sports Injuries', 'Post-Surgery Rehab', 'Back Pain'],
      experience: '8 years',
      insurance: ['Aetna', 'BCBS', 'UnitedHealth'],
      nextAvailable: 'Tomorrow at 2:00 PM'
    },
    {
      id: 2,
      name: 'Dr. Michael Chen',
      specialty: 'Occupational Therapy',
      specialtyShort: 'OT',
      location: 'Phoenix, AZ 85004',
      distance: '3.7 miles',
      rating: 4.8,
      reviews: 94,
      image: 'https://images.unsplash.com/photo-1733685318562-c726472bc1db?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0aGVyYXBpc3QlMjBwcm9mZXNzaW9uYWwlMjBwb3J0cmFpdHxlbnwxfHx8fDE3NTY3MTk0MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      specializations: ['Pediatric OT', 'Sensory Integration', 'Fine Motor Skills'],
      experience: '12 years',
      insurance: ['Cigna', 'BCBS', 'Humana'],
      nextAvailable: 'Today at 4:30 PM'
    },
    {
      id: 3,
      name: 'Dr. Emily Rodriguez',
      specialty: 'Speech-Language Pathology',
      specialtyShort: 'SLP',
      location: 'Phoenix, AZ 85006',
      distance: '4.1 miles',
      rating: 4.9,
      reviews: 156,
      image: 'https://images.unsplash.com/photo-1631675444570-60fa2ef402ec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGhjYXJlJTIwd29ya2VyJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzU2NzIzOTI5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      specializations: ['Autism Spectrum', 'Language Delays', 'Voice Therapy'],
      experience: '6 years',
      insurance: ['Aetna', 'UnitedHealth', 'Medicaid'],
      nextAvailable: 'Monday at 10:00 AM'
    },
    {
      id: 4,
      name: 'Dr. James Wilson',
      specialty: 'Physical Therapy',
      specialtyShort: 'PT',
      location: 'Phoenix, AZ 85008',
      distance: '5.2 miles',
      rating: 4.7,
      reviews: 89,
      image: 'https://images.unsplash.com/photo-1632054224659-280be3239aff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBoZWFkc2hvdCUyMGRvY3RvcnxlbnwxfHx8fDE3NTY3NjM2NTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      specializations: ['Orthopedic Injuries', 'Geriatric PT', 'Balance Training'],
      experience: '15 years',
      insurance: ['Medicare', 'BCBS', 'Cigna'],
      nextAvailable: 'Wednesday at 1:15 PM'
    },
    {
      id: 5,
      name: 'Dr. Lisa Thompson',
      specialty: 'Occupational Therapy',
      specialtyShort: 'OT',
      location: 'Phoenix, AZ 85003',
      distance: '6.8 miles',
      rating: 4.8,
      reviews: 112,
      image: 'https://images.unsplash.com/photo-1631675444570-60fa2ef402ec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGhjYXJlJTIwd29ya2VyJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzU2NzIzOTI5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      specializations: ['Stroke Recovery', 'Hand Therapy', 'Home Safety'],
      experience: '10 years',
      insurance: ['Aetna', 'BCBS', 'Humana'],
      nextAvailable: 'Thursday at 9:30 AM'
    },
    {
      id: 6,
      name: 'Dr. David Park',
      specialty: 'Speech-Language Pathology',
      specialtyShort: 'SLP',
      location: 'Phoenix, AZ 85007',
      distance: '7.5 miles',
      rating: 4.9,
      reviews: 201,
      image: 'https://images.unsplash.com/photo-1733685318562-c726472bc1db?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0aGVyYXBpc3QlMjBwcm9mZXNzaW9uYWwlMjBwb3J0cmFpdHxlbnwxfHx8fDE3NTY3MTk0MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      specializations: ['Stuttering', 'Cognitive Communication', 'Accent Modification'],
      experience: '14 years',
      insurance: ['UnitedHealth', 'Cigna', 'BCBS'],
      nextAvailable: 'Friday at 11:00 AM'
    }
  ];

  const filteredTherapists = therapists.filter(therapist => {
    if (selectedSpecialty === 'all') return true;
    return therapist.specialty.toLowerCase().includes(selectedSpecialty.toLowerCase());
  });

  const getSpecialtyColor = (specialty: string) => {
    switch (specialty) {
      case 'Physical Therapy':
        return 'bg-blue-100 text-blue-800';
      case 'Occupational Therapy':
        return 'bg-cyan-100 text-cyan-800';
      case 'Speech-Language Pathology':
        return 'bg-indigo-100 text-indigo-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <section id="therapists" className="relative py-20">
      {/* Subtle overlay for content contrast */}
      <div className="absolute inset-0 bg-gradient-to-b from-white/50 to-blue-50/30 bg-[rgba(9,108,246,0.66)]"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Find Your Perfect Therapist
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Browse our network of licensed therapists and book your appointment today.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="mb-8">
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="md:col-span-2">
                <Input
                  type="text"
                  placeholder="Enter zip code"
                  value={searchZip}
                  onChange={(e) => setSearchZip(e.target.value)}
                  className="h-12"
                />
              </div>
              <Select value={selectedSpecialty} onValueChange={setSelectedSpecialty}>
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="Select specialty" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Specialties</SelectItem>
                  <SelectItem value="physical">Physical Therapy</SelectItem>
                  <SelectItem value="occupational">Occupational Therapy</SelectItem>
                  <SelectItem value="speech">Speech-Language Pathology</SelectItem>
                </SelectContent>
              </Select>
              <Button 
                variant="outline" 
                className="h-12"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter className="h-4 w-4 mr-2" />
                More Filters
              </Button>
            </div>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-gray-600">
            Showing {filteredTherapists.length} therapists in Phoenix, AZ
          </p>
        </div>

        {/* Therapist Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTherapists.map((therapist) => (
            <Card key={therapist.id} className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
              <CardHeader className="pb-4">
                <div className="flex items-start space-x-4">
                  <div className="relative">
                    <ImageWithFallback
                      src={therapist.image}
                      alt={therapist.name}
                      className="w-16 h-16 rounded-full object-cover"
                    />
                    <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 rounded-full border-2 border-white flex items-center justify-center">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg">{therapist.name}</h3>
                    <Badge variant="secondary" className={getSpecialtyColor(therapist.specialty)}>
                      {therapist.specialtyShort}
                    </Badge>
                    <div className="flex items-center mt-2 text-sm text-gray-600">
                      <MapPin className="h-4 w-4 mr-1" />
                      {therapist.distance}
                    </div>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {/* Rating */}
                <div className="flex items-center space-x-2">
                  <div className="flex items-center">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="ml-1 font-medium">{therapist.rating}</span>
                  </div>
                  <span className="text-gray-500">({therapist.reviews} reviews)</span>
                </div>

                {/* Specializations */}
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-2">Specializations:</p>
                  <div className="flex flex-wrap gap-1">
                    {therapist.specializations.map((spec, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {spec}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Experience */}
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Experience:</span>
                  <span className="font-medium">{therapist.experience}</span>
                </div>

                {/* Next Available */}
                <div className="bg-green-50 rounded-lg p-3">
                  <p className="text-sm font-medium text-green-800">Next Available:</p>
                  <p className="text-sm text-green-600">{therapist.nextAvailable}</p>
                </div>

                {/* Action Buttons */}
                <div className="grid grid-cols-2 gap-2 pt-2">
                  <Button variant="outline" size="sm">
                    <Phone className="h-4 w-4 mr-1" />
                    Call
                  </Button>
                  <Button size="sm">
                    Book Now
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-12">
          <Button variant="outline" size="lg">
            Load More Therapists
          </Button>
        </div>
      </div>
    </section>
  );
}