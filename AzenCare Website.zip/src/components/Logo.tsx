import React from 'react';
import logoImage from 'figma:asset/ac342b22be2bc4d382908f817a9b80402acc2f87.png';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export function Logo({ className = '', size = 'md' }: LogoProps) {
  const logoSizes = {
    sm: 'h-8 w-auto',
    md: 'h-12 w-auto',
    lg: 'h-16 w-auto'
  };

  return (
    <div className={`flex items-center ${className}`}>
      <img 
        src={logoImage} 
        alt="AzenCare Logo" 
        className={logoSizes[size]}
      />
    </div>
  );
}