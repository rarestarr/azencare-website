import image_139212a1d0e974b6b8d0e5f0db07220d35b7277e from 'figma:asset/139212a1d0e974b6b8d0e5f0db07220d35b7277e.png';
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  User, 
  Users, 
  Building2, 
  Award,
  MapPin,
  Phone,
  Mail,
  Linkedin,
  Heart,
  Target,
  Lightbulb,
  CheckCircle
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function AboutUs() {
  const teamValues = [
    {
      title: "Patient-First Approach",
      description: "Every decision is guided by improving patient outcomes and access to care",
      icon: Heart
    },
    {
      title: "Therapist Empowerment", 
      description: "Building tools that reduce administrative burden and enhance clinical practice",
      icon: Award
    },
    {
      title: "Innovation with Purpose",
      description: "Leveraging technology to solve real healthcare challenges, not creating solutions in search of problems",
      icon: Lightbulb
    },
    {
      title: "Equity & Accessibility",
      description: "Ensuring quality therapy is available to all communities, regardless of geography or socioeconomic status",
      icon: Target
    }
  ];

  const advisoryPositions = [
    "Chief Medical Officer (Healthcare Strategy)",
    "Clinical Advisory Board (OT, PT, SLP specialists)", 
    "Technology Advisory (Healthcare IT)",
    "Business Development (Healthcare Partnerships)"
  ];

  const companyDetails = [
    { label: "Legal Name", value: "AzenCare LLC" },
    { label: "Registration", value: "New York State" },
    { label: "EIN", value: "Available upon request" },
    { label: "Headquarters", value: "New York, NY 11374" },
    { label: "Founded", value: "2024" },
    { label: "Trademark", value: "AzenCare™ (Pending)" }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge className="bg-blue-100 text-blue-700 border-blue-200 mb-6">
            <Users className="w-4 h-4 mr-2" />
            About AzenCare
          </Badge>
          
          <h2 className="text-4xl lg:text-5xl text-gray-900 mb-6">
            Meet the Team Building Better Healthcare
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Founded by parents and healthcare advocates who experienced the therapy access crisis firsthand, 
            AzenCare combines personal mission with professional expertise.
          </p>
        </div>

        {/* Founder Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <div className="relative">
            {/* Founder Image Placeholder */}
            <Card className="border-blue-200 bg-white overflow-hidden">
              <div className="aspect-[4/3] overflow-hidden">
                <ImageWithFallback 
                  src={image_139212a1d0e974b6b8d0e5f0db07220d35b7277e} 
                  alt="Alexander Azenabor, Founder & CEO"
                  className="w-full h-full object-cover px-[4px] my-[0px] p-[0px] m-[0px]"
                />
              </div>
              <CardContent className="p-6 text-center">
                <h3 className="text-2xl text-gray-900 mb-2">Founder & CEO</h3>
                <p className="text-gray-600 mb-4">Alexander Azenabor, MS OTR/L - Licensed Occupational Therapist & Healthcare Entrepreneur</p>
                <div className="flex justify-center gap-3">
                  <Button variant="outline" size="sm">
                    <Linkedin className="w-4 h-4 mr-2" />
                    LinkedIn
                  </Button>
                  <Button variant="outline" size="sm">
                    <Mail className="w-4 h-4 mr-2" />
                    Contact
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="border-teal-200 bg-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5 text-teal-600" />
                  Clinical Background
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  Alexander Azenabor is a licensed Occupational Therapist with deep clinical expertise 
                  in helping patients achieve their therapeutic goals. His hands-on experience in healthcare 
                  delivery provides the foundation for understanding both patient needs and provider challenges.
                </p>
              </CardContent>
            </Card>

            <Card className="border-blue-200 bg-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-blue-600" />
                  Entrepreneurial Vision
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  Combining clinical background with entrepreneurial vision, Alexander created AzenCare 
                  to streamline access to occupational, physical, and speech therapy while ensuring 
                  HIPAA compliance and maintaining the highest standards of patient care.
                </p>
              </CardContent>
            </Card>

            <Card className="border-purple-200 bg-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-purple-600" />
                  Mission & Impact
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  Alexander's mission is simple: remove barriers to care and make therapy instantly 
                  accessible nationwide. AzenCare transforms how families connect with qualified 
                  therapists through innovative digital health technology.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Team Values */}
        <div className="mb-16">
          <h3 className="text-3xl text-gray-900 mb-8 text-center">
            Our Core Values
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {teamValues.map((value, index) => (
              <Card key={index} className="text-center border-green-200 bg-white hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <value.icon className="w-6 h-6 text-green-600" />
                  </div>
                  <CardTitle className="text-lg">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-sm leading-relaxed">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>



        {/* Contact Information */}
        <Card className="bg-gradient-to-r from-teal-600 to-blue-600 border-none text-white">
          <CardContent className="p-8 lg:p-12">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-3xl mb-4">Get to Know Us Better</h3>
                <p className="text-teal-100 text-lg mb-6">
                  We're always excited to connect with fellow healthcare advocates, 
                  potential team members, and anyone passionate about improving therapy access.
                </p>
                
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-teal-200" />
                    <span className="text-teal-100">New York, NY 11374</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-teal-200" />
                    <span className="text-teal-100">(718) 772-2453</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-teal-200" />
                    <span className="text-teal-100">hello@azencare.com</span>
                  </div>
                </div>
              </div>
              
              <div className="text-center lg:text-right">
                <Button 
                  size="lg"
                  className="h-14 px-8 bg-white text-teal-600 hover:bg-teal-50 mb-4"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  Schedule a Meeting
                </Button>
                
                <p className="text-teal-200 text-sm">
                  We'd love to hear from you and share our vision for better healthcare access
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}