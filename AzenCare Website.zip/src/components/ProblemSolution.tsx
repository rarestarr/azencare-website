import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  AlertTriangle, 
  Clock, 
  Users, 
  MapPin, 
  Phone, 
  Smartphone,
  Zap,
  CheckCircle,
  ArrowRight,
  TrendingUp
} from 'lucide-react';

export function ProblemSolution() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge className="bg-red-100 text-red-700 border-red-200 mb-4">
            Critical Healthcare Challenge
          </Badge>
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            The Therapy Access Crisis
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            While therapy demand has grown 300% in recent years, the systems connecting therapists 
            with patients remain stuck in the past, creating unnecessary barriers to essential care.
          </p>
        </div>

        {/* Problem Section */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              The Outdated System is Failing Everyone
            </h3>
            <p className="text-lg text-gray-600">
              Current therapy access relies on fragmented, inefficient processes that hurt both patients and providers
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Problem Stats */}
            <div className="space-y-6">
              <Card className="border-red-200 bg-red-50/50">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-red-600" />
                    <CardTitle className="text-lg">Patient Perspective</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-semibold text-red-900">4-8 Week Wait Times</div>
                      <div className="text-sm text-red-700">Average time to get first appointment</div>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Phone className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-semibold text-red-900">15+ Phone Calls</div>
                      <div className="text-sm text-red-700">To find one available therapist</div>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-semibold text-red-900">Limited Geographic Access</div>
                      <div className="text-sm text-red-700">Especially in underserved communities</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-orange-200 bg-orange-50/50">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-orange-600" />
                    <CardTitle className="text-lg">Therapist Perspective</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start gap-3">
                    <TrendingUp className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-semibold text-orange-900">30% Practice Growth Potential</div>
                      <div className="text-sm text-orange-700">Lost due to poor patient matching</div>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-semibold text-orange-900">20+ Hours Weekly</div>
                      <div className="text-sm text-orange-700">Spent on administrative tasks instead of patient care</div>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Phone className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-semibold text-orange-900">Outdated Referral Systems</div>
                      <div className="text-sm text-orange-700">Relying on word-of-mouth and paper directories</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Problem Visualization */}
            <div className="relative">
              <div className="bg-gradient-to-br from-red-50 to-orange-50 rounded-2xl p-8 border border-red-200">
                <h4 className="font-bold text-xl text-gray-900 mb-6 text-center">
                  Current Patient Journey
                </h4>
                
                <div className="space-y-4">
                  <div className="flex items-center gap-4 p-4 bg-white rounded-lg border border-red-200">
                    <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-red-600 font-bold text-sm">1</span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Doctor Referral</div>
                      <div className="text-sm text-gray-600">Generic referral with no specific matching</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 p-4 bg-white rounded-lg border border-red-200">
                    <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-red-600 font-bold text-sm">2</span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Search & Call</div>
                      <div className="text-sm text-gray-600">Hours spent calling practices, many don't answer</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 p-4 bg-white rounded-lg border border-red-200">
                    <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-red-600 font-bold text-sm">3</span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Wait Lists</div>
                      <div className="text-sm text-gray-600">Added to multiple wait lists, no transparency</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 p-4 bg-white rounded-lg border border-red-200">
                    <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-red-600 font-bold text-sm">4</span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Give Up or Settle</div>
                      <div className="text-sm text-gray-600">60% abandon care or accept poor fit</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Solution Section */}
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-3xl p-12">
          <div className="text-center mb-12">
            <Badge className="bg-blue-100 text-blue-700 border-blue-200 mb-4">
              <Zap className="w-4 h-4 mr-2" />
              AzenCare Solution
            </Badge>
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              Intelligent Matching, Instant Access
            </h3>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Our platform uses smart algorithms and real-time data to connect patients 
              with the right therapists at the right time, eliminating barriers and delays.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Solution Features */}
            <div className="space-y-6">
              <Card className="border-blue-200 bg-white/70 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-blue-600" />
                    <CardTitle className="text-lg">Instant Therapist Discovery</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    AI-powered matching based on location, specialty, availability, insurance, and patient preferences.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-green-200 bg-white/70 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-5 h-5 text-green-600" />
                    <CardTitle className="text-lg">Real-Time Availability</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Live scheduling system shows actual availability, allowing immediate booking or waitlist positioning.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-purple-200 bg-white/70 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-purple-600" />
                    <CardTitle className="text-lg">Quality-First Network</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Verified, licensed therapists with detailed profiles, specializations, and patient reviews.
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* New Patient Journey */}
            <div className="relative">
              <div className="bg-gradient-to-br from-blue-100 to-green-100 rounded-2xl p-8 border border-blue-200">
                <h4 className="font-bold text-xl text-gray-900 mb-6 text-center">
                  AzenCare Patient Journey
                </h4>
                
                <div className="space-y-4">
                  <div className="flex items-center gap-4 p-4 bg-white rounded-lg border border-blue-200">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-blue-600 font-bold text-sm">1</span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Smart Search</div>
                      <div className="text-sm text-gray-600">Enter preferences, get matched instantly</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 p-4 bg-white rounded-lg border border-green-200">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-green-600 font-bold text-sm">2</span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">View & Compare</div>
                      <div className="text-sm text-gray-600">See profiles, availability, reviews in real-time</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 p-4 bg-white rounded-lg border border-purple-200">
                    <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-purple-600 font-bold text-sm">3</span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Book Instantly</div>
                      <div className="text-sm text-gray-600">Secure appointment in under 5 minutes</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 p-4 bg-white rounded-lg border border-blue-200">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="w-4 h-4 text-blue-600" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Start Therapy</div>
                      <div className="text-sm text-gray-600">Focus on healing, not hunting for care</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Impact Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12 pt-8 border-t border-blue-200">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">90%</div>
              <div className="text-sm text-gray-600">Faster Access</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">5 min</div>
              <div className="text-sm text-gray-600">Avg. Booking Time</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600">95%</div>
              <div className="text-sm text-gray-600">Match Accuracy</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">24/7</div>
              <div className="text-sm text-gray-600">Platform Access</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}