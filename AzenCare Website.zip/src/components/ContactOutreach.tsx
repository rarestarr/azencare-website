import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { 
  Mail, 
  Phone, 
  MapPin,
  Download,
  Send,
  Handshake,
  Building2,
  FileText,
  Users,
  DollarSign,
  MessageCircle,
  ExternalLink,
  Clock
} from 'lucide-react';

export function ContactOutreach() {
  const [generalForm, setGeneralForm] = React.useState({
    name: '',
    email: '',
    organization: '',
    message: '',
    inquiryType: ''
  });

  const [partnershipForm, setPartnershipForm] = React.useState({
    name: '',
    email: '',
    organization: '',
    organizationType: '',
    partnershipInterest: '',
    message: ''
  });

  const inquiryTypes = [
    { value: 'general', label: 'General Information' },
    { value: 'therapist', label: 'Therapist Sign-up' },
    { value: 'investor', label: 'Investment Inquiry' },
    { value: 'partnership', label: 'Partnership Opportunity' },
    { value: 'media', label: 'Media / Press' },
    { value: 'technical', label: 'Technical Support' }
  ];

  const organizationTypes = [
    { value: 'healthcare-system', label: 'Healthcare System / Hospital' },
    { value: 'academic', label: 'Academic Institution' },
    { value: 'government', label: 'Government / Public Health' },
    { value: 'nonprofit', label: 'Nonprofit Organization' },
    { value: 'grant-foundation', label: 'Grant Foundation' },
    { value: 'private-practice', label: 'Private Practice Group' },
    { value: 'technology', label: 'Technology Partner' },
    { value: 'other', label: 'Other' }
  ];

  const partnershipOptions = [
    { value: 'clinical-integration', label: 'Clinical Integration' },
    { value: 'research-collaboration', label: 'Research Collaboration' },
    { value: 'grant-funding', label: 'Grant Funding' },
    { value: 'strategic-partnership', label: 'Strategic Partnership' },
    { value: 'pilot-program', label: 'Pilot Program' },
    { value: 'other', label: 'Other Partnership Type' }
  ];

  const handleGeneralSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('General inquiry submitted:', generalForm);
    // Handle form submission
    alert('Thank you for your inquiry! We\'ll respond within 24 hours.');
  };

  const handlePartnershipSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Partnership inquiry submitted:', partnershipForm);
    // Handle form submission
    alert('Thank you for your partnership interest! Our team will contact you within 2 business days.');
  };

  const contactMethods = [
    {
      type: 'General Inquiries',
      icon: Mail,
      primary: 'hello@azencare.com',
      secondary: 'Response within 24 hours',
      action: 'mailto:hello@azencare.com'
    },
    {
      type: 'Phone Support',
      icon: Phone,
      primary: '(718) 772-2453',
      secondary: 'Mon-Fri, 9AM-6PM EST',
      action: 'tel:718-772-2453'
    },
    {
      type: 'Business Address',
      icon: MapPin,
      primary: 'New York, NY 11374',
      secondary: 'AzenCare LLC Headquarters',
      action: null
    }
  ];

  const downloadResources = [
    {
      title: 'AzenCare Overview',
      description: 'One-page summary of our platform, mission, and impact',
      icon: FileText,
      size: '2.1 MB PDF',
      audience: 'All stakeholders'
    },
    {
      title: 'Therapist Information Package',
      description: 'Detailed guide for therapists interested in joining our network',
      icon: Users,
      size: '1.8 MB PDF',
      audience: 'Healthcare providers'
    },
    {
      title: 'Partnership Opportunities',
      description: 'Comprehensive overview of collaboration possibilities',
      icon: Handshake,
      size: '2.4 MB PDF',
      audience: 'Organizations & institutions'
    },
    {
      title: 'Investment Summary',
      description: 'Executive summary for qualified investors (NDA required)',
      icon: DollarSign,
      size: '1.5 MB PDF',
      audience: 'Accredited investors'
    }
  ];

  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge className="bg-blue-100 text-blue-700 border-blue-200 mb-6">
            <MessageCircle className="w-4 h-4 mr-2" />
            Contact & Outreach
          </Badge>
          
          <h2 className="text-4xl lg:text-5xl text-gray-900 mb-6">
            Let's Connect
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Whether you're a therapist, investor, potential partner, or someone passionate about 
            improving healthcare access—we'd love to hear from you.
          </p>
        </div>

        {/* Contact Methods */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {contactMethods.map((method, index) => (
            <Card key={index} className="text-center border-teal-200 bg-white hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <method.icon className="w-6 h-6 text-teal-600" />
                </div>
                <h3 className="font-medium text-gray-900 mb-2">{method.type}</h3>
                <div className="text-lg text-teal-600 mb-1">
                  {method.action ? (
                    <a href={method.action} className="hover:underline">
                      {method.primary}
                    </a>
                  ) : (
                    method.primary
                  )}
                </div>
                <p className="text-sm text-gray-600">{method.secondary}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Contact Forms */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {/* General Inquiry Form */}
          <Card className="border-blue-200 bg-white">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-blue-600" />
                General Inquiry Form
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleGeneralSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="gen-name">Name *</Label>
                    <Input
                      id="gen-name"
                      value={generalForm.name}
                      onChange={(e) => setGeneralForm(prev => ({ ...prev, name: e.target.value }))}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="gen-email">Email *</Label>
                    <Input
                      id="gen-email"
                      type="email"
                      value={generalForm.email}
                      onChange={(e) => setGeneralForm(prev => ({ ...prev, email: e.target.value }))}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="gen-organization">Organization (Optional)</Label>
                  <Input
                    id="gen-organization"
                    value={generalForm.organization}
                    onChange={(e) => setGeneralForm(prev => ({ ...prev, organization: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="inquiry-type">Inquiry Type</Label>
                  <Select onValueChange={(value) => setGeneralForm(prev => ({ ...prev, inquiryType: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select inquiry type" />
                    </SelectTrigger>
                    <SelectContent>
                      {inquiryTypes.map(type => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="gen-message">Message *</Label>
                  <Textarea
                    id="gen-message"
                    value={generalForm.message}
                    onChange={(e) => setGeneralForm(prev => ({ ...prev, message: e.target.value }))}
                    className="min-h-24"
                    required
                  />
                </div>

                <Button type="submit" className="w-full">
                  <Send className="w-4 h-4 mr-2" />
                  Send Inquiry
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Partnership Inquiry Form */}
          <Card className="border-purple-200 bg-white">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Handshake className="w-5 h-5 text-purple-600" />
                Grant & Partnership Inquiry
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePartnershipSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="part-name">Name *</Label>
                    <Input
                      id="part-name"
                      value={partnershipForm.name}
                      onChange={(e) => setPartnershipForm(prev => ({ ...prev, name: e.target.value }))}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="part-email">Email *</Label>
                    <Input
                      id="part-email"
                      type="email"
                      value={partnershipForm.email}
                      onChange={(e) => setPartnershipForm(prev => ({ ...prev, email: e.target.value }))}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="part-organization">Organization *</Label>
                  <Input
                    id="part-organization"
                    value={partnershipForm.organization}
                    onChange={(e) => setPartnershipForm(prev => ({ ...prev, organization: e.target.value }))}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="org-type">Organization Type</Label>
                  <Select onValueChange={(value) => setPartnershipForm(prev => ({ ...prev, organizationType: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select organization type" />
                    </SelectTrigger>
                    <SelectContent>
                      {organizationTypes.map(type => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="partnership-interest">Partnership Interest</Label>
                  <Select onValueChange={(value) => setPartnershipForm(prev => ({ ...prev, partnershipInterest: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select partnership type" />
                    </SelectTrigger>
                    <SelectContent>
                      {partnershipOptions.map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="part-message">Partnership Details *</Label>
                  <Textarea
                    id="part-message"
                    value={partnershipForm.message}
                    onChange={(e) => setPartnershipForm(prev => ({ ...prev, message: e.target.value }))}
                    className="min-h-24"
                    placeholder="Tell us about your organization and partnership interest..."
                    required
                  />
                </div>

                <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700">
                  <Handshake className="w-4 h-4 mr-2" />
                  Submit Partnership Inquiry
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>



        {/* Response Time Commitment */}
        <Card className="mt-16 bg-gradient-to-r from-teal-600 to-blue-600 border-none text-white">
          <CardContent className="p-8 text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Clock className="w-6 h-6 text-teal-200" />
              <h3 className="text-2xl">Our Response Commitment</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div>
                <div className="text-3xl mb-2">24 hrs</div>
                <div className="text-teal-200">General inquiries</div>
              </div>
              <div>
                <div className="text-3xl mb-2">48 hrs</div>
                <div className="text-teal-200">Partnership requests</div>
              </div>
              <div>
                <div className="text-3xl mb-2">Same day</div>
                <div className="text-teal-200">Urgent matters</div>
              </div>
            </div>

            <p className="text-teal-100 max-w-2xl mx-auto">
              We believe in responsive communication. Every inquiry matters to us, and we're committed 
              to providing thoughtful, timely responses to help move your questions and opportunities forward.
            </p>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}