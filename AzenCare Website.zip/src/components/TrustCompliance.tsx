import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  Shield, 
  Lock, 
  FileText, 
  CreditCard,
  CheckCircle,
  Eye,
  Users,
  Server,
  Award,
  Building2,
  ExternalLink,
  Download
} from 'lucide-react';

export function TrustCompliance() {
  const complianceFeatures = [
    {
      title: "HIPAA Compliance",
      description: "Built from the ground up with healthcare privacy regulations in mind",
      icon: Shield,
      details: [
        "End-to-end encryption for all patient communications",
        "Secure data storage with access controls",
        "Regular security audits and compliance reviews",
        "Staff training on privacy requirements"
      ],
      status: "Implemented"
    },
    {
      title: "Data Privacy Protection",
      description: "Comprehensive privacy controls protecting patient and therapist information",
      icon: Lock,
      details: [
        "Minimal data collection principles",
        "User consent management system", 
        "Data anonymization for analytics",
        "Right to deletion and data portability"
      ],
      status: "Active"
    },
    {
      title: "Secure Payment Processing",
      description: "PCI-compliant payment infrastructure through Stripe integration",
      icon: CreditCard,
      details: [
        "Stripe Connect for secure therapist payouts",
        "PCI DSS Level 1 compliance",
        "Fraud detection and prevention",
        "Bank-grade encryption for financial data"
      ],
      status: "Integrated"
    },
    {
      title: "Platform Security",
      description: "Enterprise-grade security measures protecting all user interactions",
      icon: Server,
      details: [
        "Multi-factor authentication options",
        "SSL/TLS encryption for all connections",
        "Regular penetration testing",
        "24/7 security monitoring"
      ],
      status: "Active"
    }
  ];

  const policies = [
    {
      title: "Privacy Policy",
      description: "How we collect, use, and protect your personal information",
      icon: Eye,
      lastUpdated: "January 2025"
    },
    {
      title: "Terms of Service",
      description: "User rights and responsibilities for AzenCare platform usage",
      icon: FileText,
      lastUpdated: "January 2025"
    },
    {
      title: "HIPAA Business Associate Agreement",
      description: "Healthcare privacy commitments for healthcare partners",
      icon: Shield,
      lastUpdated: "January 2025"
    },
    {
      title: "Cookie Policy",
      description: "Information about cookies and tracking technologies we use",
      icon: Server,
      lastUpdated: "January 2025"
    }
  ];

  const certifications = [
    {
      title: "AzenCare™ LLC",
      type: "Business Registration",
      authority: "New York State",
      status: "Active",
      icon: Building2
    },
    {
      title: "HIPAA Compliance",
      type: "Healthcare Privacy",
      authority: "U.S. Department of Health",
      status: "Compliant",
      icon: Shield
    },
    {
      title: "Stripe Partnership",
      type: "Payment Processing",
      authority: "PCI DSS Level 1",
      status: "Certified",
      icon: CreditCard
    },
    {
      title: "Trademark Application",
      type: "Intellectual Property",
      authority: "USPTO",
      status: "Pending",
      icon: Award
    }
  ];

  return (
    <section id="trust-compliance" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge className="bg-green-100 text-green-700 border-green-200 mb-6">
            <Shield className="w-4 h-4 mr-2" />
            Trust & Compliance
          </Badge>
          
          <h2 className="text-4xl lg:text-5xl text-gray-900 mb-6">
            Built on Trust, Secured by Design
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Healthcare requires the highest standards of security, privacy, and compliance. 
            AzenCare exceeds industry requirements to protect patient data and ensure regulatory adherence.
          </p>
        </div>

        {/* Compliance Features */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {complianceFeatures.map((feature, index) => (
            <Card key={index} className="border-green-200 bg-green-50/30 hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <feature.icon className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">{feature.title}</CardTitle>
                      <Badge className="bg-green-100 text-green-700 mt-1 text-xs">
                        {feature.status}
                      </Badge>
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 mt-3">{feature.description}</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {feature.details.map((detail, detailIndex) => (
                    <div key={detailIndex} className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-700">{detail}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>



        {/* Certifications & Registrations */}
        <div className="mb-16">
          <h3 className="text-3xl text-gray-900 mb-8 text-center">
            Certifications & Business Registration
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {certifications.map((cert, index) => (
              <Card key={index} className="text-center border-purple-200 bg-purple-50/30 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <cert.icon className="w-6 h-6 text-purple-600" />
                  </div>
                  <CardTitle className="text-lg">{cert.title}</CardTitle>
                  <p className="text-sm text-gray-600">{cert.type}</p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="text-sm text-gray-700">
                      <strong>Authority:</strong> {cert.authority}
                    </div>
                    <Badge className={
                      cert.status === 'Active' || cert.status === 'Compliant' || cert.status === 'Certified' 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-yellow-100 text-yellow-700'
                    }>
                      {cert.status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Security Commitment */}
        <Card className="bg-gradient-to-r from-green-600 to-teal-600 border-none text-white">
          <CardContent className="p-8 lg:p-12">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <Shield className="w-8 h-8 text-green-200" />
                  <h3 className="text-3xl">Our Security Commitment</h3>
                </div>
                
                <p className="text-green-100 text-lg mb-6">
                  Healthcare data deserves the highest level of protection. We've invested in 
                  enterprise-grade security infrastructure and maintain strict compliance standards 
                  to keep your information safe.
                </p>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="text-center">
                    <div className="text-2xl mb-1">24/7</div>
                    <div className="text-sm text-green-200">Security Monitoring</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl mb-1">256-bit</div>
                    <div className="text-sm text-green-200">Encryption Standard</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl mb-1">100%</div>
                    <div className="text-sm text-green-200">HIPAA Compliant</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl mb-1">SOC 2</div>
                    <div className="text-sm text-green-200">Type II (Planned)</div>
                  </div>
                </div>
              </div>
              
              <div className="text-center lg:text-right">
                <Button 
                  size="lg"
                  className="h-14 px-8 bg-white text-green-600 hover:bg-green-50 mb-4"
                >
                  <Shield className="mr-2 h-5 w-5" />
                  Security Report
                </Button>
                
                <p className="text-green-200 text-sm">
                  Request our detailed security and compliance documentation
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}