import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { 
  CheckCircle, 
  Code, 
  Database, 
  Smartphone, 
  Shield,
  Zap,
  GitBranch,
  Users,
  Globe,
  ArrowRight,
  Play
} from 'lucide-react';

export function TechProgress() {
  const milestones = [
    {
      phase: "Research & Validation",
      status: "completed",
      progress: 100,
      items: [
        { name: "Market Research", completed: true },
        { name: "User Interviews", completed: true },
        { name: "Competitive Analysis", completed: true },
        { name: "MVP Specifications", completed: true }
      ]
    },
    {
      phase: "Design & Prototyping",
      status: "completed",
      progress: 100,
      items: [
        { name: "User Experience Design", completed: true },
        { name: "Figma Prototype", completed: true },
        { name: "Design System", completed: true },
        { name: "User Testing", completed: true }
      ]
    },
    {
      phase: "Technical Foundation",
      status: "completed",
      progress: 100,
      items: [
        { name: "Backend Architecture", completed: true },
        { name: "Supabase Integration", completed: true },
        { name: "Authentication System", completed: true },
        { name: "Database Schema", completed: true }
      ]
    },
    {
      phase: "Development & Testing",
      status: "current",
      progress: 25,
      items: [
        { name: "Frontend Development", completed: false },
        { name: "API Integration", completed: false },
        { name: "Quality Assurance", completed: false },
        { name: "Performance Optimization", completed: false }
      ]
    }
  ];

  const techStack = [
    { name: "React + TypeScript", icon: Code, status: "production", description: "Modern frontend framework" },
    { name: "Supabase", icon: Database, status: "configured", description: "Postgres database & real-time API" },
    { name: "Authentication", icon: Shield, status: "configured", description: "Secure user management" },
    { name: "Mobile-First", icon: Smartphone, status: "designed", description: "Responsive web application" },
    { name: "Real-time Updates", icon: Zap, status: "configured", description: "Live availability tracking" },
    { name: "Version Control", icon: GitBranch, status: "active", description: "Git-based development workflow" }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge className="bg-blue-100 text-blue-700 border-blue-200 mb-4">
            <Code className="w-4 h-4 mr-2" />
            Technical Progress
          </Badge>
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Built for Scale, Ready for Launch
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            AzenCare's technical foundation is complete. Our MVP has been validated, 
            backend infrastructure is deployed, and we're entering the development phase.
          </p>
        </div>

        {/* Development Timeline */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">Development Timeline</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {milestones.map((milestone, index) => (
              <Card key={index} className={`relative ${
                milestone.status === 'completed' ? 'border-green-200 bg-green-50/50' :
                milestone.status === 'current' ? 'border-blue-200 bg-blue-50/50' :
                'border-gray-200 bg-gray-50/50'
              }`}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{milestone.phase}</CardTitle>
                    {milestone.status === 'completed' && (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    )}
                  </div>
                  <Progress value={milestone.progress} className="h-2" />
                  <div className="text-sm text-gray-600">{milestone.progress}% Complete</div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {milestone.items.map((item, itemIndex) => (
                      <div key={itemIndex} className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${
                          item.completed ? 'bg-green-500' : 'bg-gray-300'
                        }`}></div>
                        <span className={`text-sm ${
                          item.completed ? 'text-gray-900' : 'text-gray-500'
                        }`}>
                          {item.name}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Technical Stack */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-8">Technical Infrastructure</h3>
            
            <div className="space-y-4">
              {techStack.map((tech, index) => (
                <Card key={index} className="border-gray-200 hover:border-blue-300 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <tech.icon className="w-5 h-5 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-semibold text-gray-900">{tech.name}</span>
                          <Badge 
                            variant={
                              tech.status === 'production' ? 'default' :
                              tech.status === 'configured' ? 'secondary' :
                              'outline'
                            }
                            className="text-xs"
                          >
                            {tech.status}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600">{tech.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Live Demo Section */}
          <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Interactive Prototype</h3>
              <p className="text-gray-600">
                Experience the AzenCare platform through our fully functional Figma prototype
              </p>
            </div>

            <div className="space-y-4 mb-6">
              <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <span className="text-green-800">User Registration & Authentication</span>
              </div>
              <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <span className="text-green-800">Therapist Search & Filtering</span>
              </div>
              <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <span className="text-green-800">Booking & Scheduling Interface</span>
              </div>
              <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <span className="text-green-800">Therapist Profile Management</span>
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <Button size="lg" className="w-full">
                <Play className="mr-2 h-5 w-5" />
                View Interactive Demo
              </Button>
              <Button variant="outline" size="lg" className="w-full">
                <Code className="mr-2 h-5 w-5" />
                Technical Documentation
              </Button>
            </div>
          </div>
        </div>

        {/* Next Phase */}
        <div className="mt-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-8 text-white">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold mb-4">Ready for Development Phase</h3>
              <p className="text-blue-100 mb-6">
                With our technical foundation complete and MVP validated, we're ready to scale development 
                and bring AzenCare to market. Join us in revolutionizing therapy access.
              </p>
              
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <div className="text-2xl font-bold">6 months</div>
                  <div className="text-sm text-blue-200">To beta launch</div>
                </div>
                <div>
                  <div className="text-2xl font-bold">$1.2M</div>
                  <div className="text-sm text-blue-200">Development budget</div>
                </div>
              </div>
            </div>
            
            <div className="text-center lg:text-right">
              <Button 
                size="lg" 
                variant="secondary"
                className="bg-white text-blue-600 hover:bg-blue-50"
              >
                Partner With Us
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}