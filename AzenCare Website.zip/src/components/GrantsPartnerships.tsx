import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Heart, 
  Users, 
  MapPin, 
  TrendingUp,
  Building2,
  FileText,
  Handshake,
  Award,
  Target,
  Globe,
  ArrowRight,
  Phone,
  Mail
} from 'lucide-react';

export function GrantsPartnerships() {
  const impactStats = [
    { value: "60%", label: "Reduction in admin time", description: "For participating therapists" },
    { value: "40%", label: "Faster patient matching", description: "Compared to traditional methods" },
    { value: "300+", label: "Patients in pipeline", description: "Waiting for platform launch" },
    { value: "12", label: "Underserved markets", description: "Identified for initial rollout" }
  ];

  const socialImpact = [
    {
      title: "Increased Therapy Access",
      description: "Breaking down barriers that prevent patients from finding qualified therapists",
      icon: Users,
      metric: "89% of Americans report therapy access challenges"
    },
    {
      title: "Geographic Equity",
      description: "Focusing on rural and underserved urban areas with limited therapy options",
      icon: MapPin,
      metric: "73% of rural counties lack adequate mental health services"
    },
    {
      title: "Healthcare System Relief",
      description: "Reducing strain on primary care by improving therapy referral efficiency",
      icon: Building2,
      metric: "Average 4-8 week wait reduced to same-day matching"
    },
    {
      title: "Economic Empowerment",
      description: "Helping therapists grow sustainable practices while serving more patients",
      icon: TrendingUp,
      metric: "30% potential practice growth for participating therapists"
    }
  ];

  const partnershipTypes = [
    {
      type: "Healthcare Systems",
      description: "Integrate AzenCare into existing referral workflows",
      benefits: ["Reduced referral friction", "Improved patient satisfaction", "Better care coordination"],
      icon: Building2
    },
    {
      type: "Academic Institutions", 
      description: "Research partnerships and therapy training programs",
      benefits: ["Student practicum placements", "Research opportunities", "Innovation collaboration"],
      icon: Award
    },
    {
      type: "Grant Organizations",
      description: "Healthcare access and technology innovation funding",
      benefits: ["Social impact measurement", "Community health outcomes", "Scalable intervention model"],
      icon: Target
    },
    {
      type: "State & Local Government",
      description: "Public health initiatives and workforce development",
      benefits: ["Mental health policy support", "Economic development", "Rural healthcare access"],
      icon: Globe
    }
  ];

  return (
    <section id="grants-partnerships" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge className="bg-purple-100 text-purple-700 border-purple-200 mb-6">
            <Handshake className="w-4 h-4 mr-2" />
            Grants & Partnerships
          </Badge>
          
          <h2 className="text-4xl lg:text-5xl text-gray-900 mb-6">
            Building Better Healthcare Together
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            AzenCare's mission extends beyond technology—we're creating lasting social impact 
            by making quality therapy accessible to everyone, everywhere.
          </p>
        </div>

        {/* Founder Story */}
        <div className="bg-gradient-to-br from-blue-50 to-teal-50 rounded-3xl p-8 lg:p-12 mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Heart className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="text-2xl text-gray-900">Our Founding Story</h3>
              </div>
              
              <div className="space-y-4 text-gray-700">
                <p>
                  AzenCare was born from personal experience navigating the complex world of therapy access 
                  for my son's IEP challenges. As a parent, I witnessed firsthand the frustrating barriers—
                  endless phone calls, long wait lists, and mismatched referrals that delayed essential care.
                </p>
                
                <p>
                  What started as a parent's search for better therapy options evolved into a deeper understanding: 
                  this isn't just one family's challenge—it's a systemic problem affecting millions of families 
                  across America, especially in underserved communities.
                </p>
                
                <p>
                  Today, AzenCare represents our commitment to ensuring no family faces these barriers alone. 
                  We're building technology that connects families to the right therapists at the right time, 
                  while empowering therapists to focus on what they do best—helping people heal and grow.
                </p>
              </div>
              
              <div className="mt-6 p-4 bg-white rounded-lg border border-blue-200">
                <p className="text-blue-800 italic">
                  "Every child deserves access to the therapy that will help them thrive. 
                  AzenCare is our commitment to making that a reality."
                </p>
                <div className="text-sm text-blue-600 mt-2">— Founder & CEO, AzenCare LLC</div>
              </div>
            </div>

            <div className="space-y-6">
              <Card className="border-blue-200 bg-white/80">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5 text-blue-600" />
                    Our Mission
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700">
                    Eliminate therapy access barriers through intelligent technology, 
                    creating equitable healthcare opportunities for all communities.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-teal-200 bg-white/80">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="w-5 h-5 text-teal-600" />
                    Our Vision
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700">
                    A world where finding the right therapist is as simple as a few clicks, 
                    and every therapist can build a thriving, sustainable practice.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        {/* Social Impact Metrics */}
        <div className="mb-16">
          <h3 className="text-3xl text-gray-900 mb-8 text-center">
            Social Impact & Validation
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {impactStats.map((stat, index) => (
              <Card key={index} className="text-center border-green-200 bg-green-50/30">
                <CardContent className="p-6">
                  <div className="text-4xl text-green-600 mb-2">{stat.value}</div>
                  <div className="font-medium text-gray-900 mb-1">{stat.label}</div>
                  <div className="text-sm text-gray-600">{stat.description}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {socialImpact.map((impact, index) => (
              <Card key={index} className="border-blue-200 bg-blue-50/30 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <impact.icon className="w-5 h-5 text-blue-600" />
                    </div>
                    <CardTitle className="text-xl">{impact.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 mb-3">{impact.description}</p>
                  <div className="text-sm text-blue-700 font-medium bg-blue-100 rounded-lg p-3">
                    📊 {impact.metric}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Partnership Opportunities */}
        <div className="mb-16">
          <h3 className="text-3xl text-gray-900 mb-8 text-center">
            Partnership Opportunities
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {partnershipTypes.map((partner, index) => (
              <Card key={index} className="border-purple-200 bg-purple-50/30 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                      <partner.icon className="w-6 h-6 text-purple-600" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">{partner.type}</CardTitle>
                      <p className="text-sm text-gray-600">{partner.description}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {partner.benefits.map((benefit, benefitIndex) => (
                      <div key={benefitIndex} className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                        <span className="text-gray-700 text-sm">{benefit}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Credibility & Compliance */}
        <div className="bg-gray-50 rounded-3xl p-8 lg:p-12 mb-16">
          <h3 className="text-2xl text-gray-900 mb-8 text-center">
            Outreach Credibility & Compliance
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center border-green-200 bg-white">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Building2 className="w-6 h-6 text-green-600" />
                </div>
                <h4 className="font-medium text-gray-900 mb-2">LLC Registration</h4>
                <p className="text-sm text-gray-600 mb-3">AzenCare™ LLC registered in New York</p>
                <Badge className="bg-green-100 text-green-700">EIN: Available upon request</Badge>
              </CardContent>
            </Card>

            <Card className="text-center border-blue-200 bg-white">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="w-6 h-6 text-blue-600" />
                </div>
                <h4 className="font-medium text-gray-900 mb-2">HIPAA Compliance</h4>
                <p className="text-sm text-gray-600 mb-3">Built with healthcare privacy standards</p>
                <Badge className="bg-blue-100 text-blue-700">Security First</Badge>
              </CardContent>
            </Card>

            <Card className="text-center border-purple-200 bg-white">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <FileText className="w-6 h-6 text-purple-600" />
                </div>
                <h4 className="font-medium text-gray-900 mb-2">Trademark</h4>
                <p className="text-sm text-gray-600 mb-3">AzenCare™ trademark pending</p>
                <Badge className="bg-purple-100 text-purple-700">Protected Brand</Badge>
              </CardContent>
            </Card>
          </div>
        </div>


      </div>
    </section>
  );
}