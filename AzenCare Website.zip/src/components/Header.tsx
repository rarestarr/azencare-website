import React from 'react';
import { Button } from './ui/button';
import { Menu, X, Users, UserPlus, Building2, Handshake, Info, MessageCircle } from 'lucide-react';
import { Logo } from './Logo';

interface HeaderProps {
  onTherapistSignupClick?: () => void;
}

export function Header({ onTherapistSignupClick }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const navigation = [
    { name: 'For Therapists', href: '#therapists', icon: Users },
    { name: 'Investors', href: '#investors', icon: Building2 },
    { name: 'Partnerships', href: '#grants-partnerships', icon: Handshake },
    { name: 'About', href: '#about', icon: Info },
    { name: 'Contact', href: '#contact', icon: MessageCircle },
  ];

  const handleNavClick = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <header className="bg-white/95 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <div className="flex items-center">
            <Logo className="h-8 w-auto" />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex space-x-8">
            {navigation.map((item) => (
              <button
                key={item.name}
                onClick={() => handleNavClick(item.href)}
                className="flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors font-medium text-sm"
              >
                <item.icon className="w-4 h-4" />
                {item.name}
              </button>
            ))}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center space-x-3">
            <Button
              variant="outline"
              className="border-blue-200 text-blue-600 hover:bg-blue-50 hover:border-blue-300"
              onClick={() => handleNavClick('#about')}
            >
              Learn About AzenCare
            </Button>
            <Button 
              onClick={onTherapistSignupClick}
              className="bg-blue-600 hover:bg-blue-700 shadow-sm"
            >
              <UserPlus className="mr-2 h-4 w-4" />
              Sign Up as Therapist
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200 bg-white">
            <nav className="flex flex-col space-y-3">
              {navigation.map((item) => (
                <button
                  key={item.name}
                  onClick={() => handleNavClick(item.href)}
                  className="flex items-center gap-3 text-gray-600 hover:text-blue-600 transition-colors font-medium text-left py-2 px-1"
                >
                  <item.icon className="w-4 h-4" />
                  {item.name}
                </button>
              ))}
            </nav>
            <div className="flex flex-col space-y-2 mt-4 pt-4 border-t border-gray-200">
              <Button
                variant="outline"
                className="border-blue-200 text-blue-600 hover:bg-blue-50 w-full"
                onClick={() => handleNavClick('#about')}
              >
                Learn About AzenCare
              </Button>
              <Button 
                onClick={() => {
                  onTherapistSignupClick?.();
                  setIsMenuOpen(false);
                }}
                className="bg-blue-600 hover:bg-blue-700 w-full"
              >
                <UserPlus className="mr-2 h-4 w-4" />
                Sign Up as Therapist
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}