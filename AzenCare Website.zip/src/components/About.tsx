import React from 'react';
import { Card, CardContent, CardHeader } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { LinkedinIcon, MailIcon, GraduationCapIcon, AwardIcon, UsersIcon, HeartIcon } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import ceoImage from 'figma:asset/139212a1d0e974b6b8d0e5f0db07220d35b7277e.png';

export function About() {
  const achievements = [
    {
      icon: GraduationCapIcon,
      title: 'Occupational Therapy Degree',
      description: 'SUNY Downstate Medical Center, NY',
      color: 'bg-blue-100 text-blue-800'
    },
    {
      icon: AwardIcon,
      title: 'Licensed Occupational Therapist',
      description: 'Clinical practice expertise',
      color: 'bg-cyan-100 text-cyan-800'
    },
    {
      icon: UsersIcon,
      title: '500+ Therapists Connected',
      description: 'Growing network across the US',
      color: 'bg-indigo-100 text-indigo-800'
    },
    {
      icon: HeartIcon,
      title: '10,000+ Lives Improved',
      description: 'Patient care facilitated through AzenCare',
      color: 'bg-blue-100 text-blue-800'
    }
  ];



  return (
    <section id="about" className="relative py-20">
      {/* Subtle overlay for content contrast */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-50/40 to-white/60 bg-[rgba(9,127,230,0.39)]"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            About AzenCare
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Founded in 2018 with a vision to transform healthcare accessibility, AzenCare connects 
            patients with the right therapists at the right time, anywhere in the United States.
          </p>
        </div>

        {/* CEO Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start mb-20">
          {/* CEO Image and Contact */}
          <div className="space-y-6">
            <Card className="overflow-hidden">
              <div className="relative">
                <ImageWithFallback
                  src={ceoImage}
                  alt="Alexander Azenabor, MS OTR/L, CEO of AzenCare"
                  className="w-full h-96 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent bg-[rgba(0,0,0,0)]"></div>
              </div>
              <CardHeader className="text-center">
                <h3 className="text-2xl font-bold text-gray-900">Alexander Azenabor, MS OTR/L</h3>
                <Badge variant="secondary" className="mx-auto bg-blue-100 text-blue-800">
                  Chief Executive Officer & Founder
                </Badge>
                <div className="flex justify-center space-x-4 pt-4">
                  <Button variant="outline" size="sm">
                    <LinkedinIcon className="h-4 w-4 mr-2" />
                    LinkedIn
                  </Button>
                  <Button variant="outline" size="sm">
                    <MailIcon className="h-4 w-4 mr-2" />
                    Contact
                  </Button>
                </div>
              </CardHeader>
            </Card>

            {/* Achievements Grid */}
            <div className="grid grid-cols-2 gap-4">
              {achievements.map((achievement, index) => {
                const IconComponent = achievement.icon;
                return (
                  <Card key={index} className="text-center">
                    <CardContent className="p-4">
                      <div className={`w-12 h-12 rounded-full ${achievement.color} flex items-center justify-center mx-auto mb-3`}>
                        <IconComponent className="h-6 w-6" />
                      </div>
                      <h4 className="font-semibold text-sm mb-1">{achievement.title}</h4>
                      <p className="text-xs text-gray-600">{achievement.description}</p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* CEO Bio */}
          <div className="space-y-6">
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 leading-relaxed">
                Alexander Azenabor is the visionary founder and CEO of AzenCare, a pioneering 
                healthcare technology platform that connects patients with qualified therapists 
                across the United States. As a licensed occupational therapist who earned his 
                degree from SUNY Downstate Medical Center in New York, Alexander brings both 
                clinical expertise and entrepreneurial vision to healthcare innovation.
              </p>
              
              <p className="text-gray-700 leading-relaxed">
                After completing his postgraduate studies, Alexander gained extensive experience 
                in clinical practice, working closely with individuals to improve their quality 
                of life through personalized therapeutic care. This hands-on experience gave him 
                unique insights into the challenges both patients and therapists face in accessing 
                and delivering quality care.
              </p>

              <p className="text-gray-700 leading-relaxed">
                Driven by a vision to make therapy more accessible, Alexander embarked on a mission 
                to bridge the gap between therapists and clients. In 2018, this vision became 
                reality with the founding of AzenCare — a platform designed to connect occupational, 
                physical, and speech therapists with those who need care, instantly and seamlessly.
              </p>

              <p className="text-gray-700 leading-relaxed">
                Since its inception, AzenCare has been committed to removing barriers to access, 
                enabling individuals across the United States to connect with qualified professionals 
                who can support their health and wellness goals. Alexander's combination of clinical 
                experience and technological innovation continues to drive the platform's growth and impact.
              </p>

              <p className="text-gray-700 leading-relaxed">
                Alexander's mission remains clear: to ensure that geography, scheduling, or other 
                barriers never prevent someone from receiving the therapeutic care they need. Through 
                AzenCare, he continues to work toward a future where quality therapy services are 
                accessible to everyone, everywhere.
              </p>
            </div>
          </div>
        </div>



        {/* Mission Statement */}
        <div className="text-center">
          <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200 bg-[rgba(0,68,255,0.11)] rounded-[44px]">
            <CardContent className="p-8 bg-[rgba(52,111,215,0.47)] rounded-[50px]">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h3>
              <p className="text-xl text-gray-700 max-w-4xl mx-auto leading-relaxed">
                "To revolutionize healthcare accessibility by creating meaningful connections 
                between patients and therapists, ensuring that geography, insurance, or 
                scheduling barriers never prevent someone from receiving the care they deserve."
              </p>
              <p className="text-lg text-gray-600 mt-4 italic">
                — Alexander Azenabor, CEO & Founder
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}