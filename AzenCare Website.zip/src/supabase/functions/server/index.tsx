import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { logger } from 'npm:hono/logger'
import { createClient } from 'jsr:@supabase/supabase-js@2'
import * as kv from './kv_store.tsx'

const app = new Hono()

// Middleware
app.use('*', cors())
app.use('*', logger(console.log))

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
)

// Health check
app.get('/make-server-7d2f6d57/health', (c) => {
  return c.json({ status: 'healthy', service: 'azencare-backend' })
})

// Therapist early interest submission endpoint
app.post('/make-server-7d2f6d57/therapist/interest', async (c) => {
  try {
    const body = await c.req.json()
    const { 
      firstName, 
      lastName, 
      practiceArea, 
      phone
    } = body

    // Validate required fields
    if (!firstName || !lastName || !practiceArea || !phone) {
      return c.json({ error: 'All fields are required' }, 400)
    }

    // Validate practice area
    const validAreas = ['OT', 'PT', 'SLP']
    if (!validAreas.includes(practiceArea)) {
      return c.json({ error: 'Invalid practice area' }, 400)
    }

    // Generate unique ID for this interest submission
    const interestId = `interest_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`
    
    // Store therapist interest
    const therapistInterest = {
      id: interestId,
      firstName,
      lastName,
      practiceArea,
      phone,
      status: 'submitted',
      submittedAt: new Date().toISOString()
    }

    await kv.set(`therapist_interest:${interestId}`, therapistInterest)
    
    // Add to practice area index for tracking
    const areaKey = `interests_by_area:${practiceArea}`
    const existingInterests = await kv.get(areaKey) || []
    existingInterests.push(interestId)
    await kv.set(areaKey, existingInterests)

    // Add to general interest list
    const allInterests = await kv.get('all_therapist_interests') || []
    allInterests.push(interestId)
    await kv.set('all_therapist_interests', allInterests)

    return c.json({ 
      success: true, 
      message: 'Interest submitted successfully',
      interestId: interestId
    })
  } catch (error) {
    console.log('Error in therapist interest submission:', error)
    return c.json({ error: 'Internal server error', details: error.message }, 500)
  }
})

// Get therapist profile
app.get('/make-server-7d2f6d57/therapist/profile/:id', async (c) => {
  try {
    const therapistId = c.req.param('id')
    const profile = await kv.get(`therapist:${therapistId}`)
    
    if (!profile) {
      return c.json({ error: 'Therapist not found' }, 404)
    }

    // Remove sensitive information
    const { password, ...safeProfile } = profile
    return c.json({ therapist: safeProfile })
  } catch (error) {
    console.log('Error fetching therapist profile:', error)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Find therapists by zip code
app.get('/make-server-7d2f6d57/therapists/search', async (c) => {
  try {
    const zipCode = c.req.query('zipCode')
    const specialty = c.req.query('specialty')
    
    if (!zipCode) {
      return c.json({ error: 'Zip code is required' }, 400)
    }

    const therapistIds = await kv.get(`therapists_by_zip:${zipCode}`) || []
    const therapists = []

    for (const id of therapistIds) {
      const profile = await kv.get(`therapist:${id}`)
      if (profile && profile.status === 'verified') {
        // Filter by specialty if provided
        if (!specialty || profile.specialty.toLowerCase().includes(specialty.toLowerCase())) {
          const { password, ...safeProfile } = profile
          therapists.push(safeProfile)
        }
      }
    }

    return c.json({ therapists, count: therapists.length })
  } catch (error) {
    console.log('Error searching therapists:', error)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Client registration endpoint
app.post('/make-server-7d2f6d57/client/register', async (c) => {
  try {
    const body = await c.req.json()
    const { 
      email, 
      password, 
      firstName, 
      lastName, 
      zipCode, 
      phone,
      therapyNeeds 
    } = body

    // Validate required fields
    if (!email || !password || !firstName || !lastName || !zipCode) {
      return c.json({ error: 'Missing required fields' }, 400)
    }

    // Create user account
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { 
        firstName,
        lastName,
        userType: 'client'
      },
      email_confirm: true // Auto-confirm for prototype
    })

    if (authError) {
      console.log('Auth error during client registration:', authError)
      return c.json({ error: 'Failed to create user account', details: authError.message }, 400)
    }

    // Store client profile
    const clientProfile = {
      userId: authData.user.id,
      email,
      firstName,
      lastName,
      zipCode,
      phone,
      therapyNeeds,
      status: 'active',
      createdAt: new Date().toISOString()
    }

    await kv.set(`client:${authData.user.id}`, clientProfile)
    await kv.set(`client_by_email:${email}`, authData.user.id)

    return c.json({ 
      success: true, 
      message: 'Client registered successfully',
      userId: authData.user.id 
    })
  } catch (error) {
    console.log('Error in client registration:', error)
    return c.json({ error: 'Internal server error', details: error.message }, 500)
  }
})

// User login endpoint
app.post('/make-server-7d2f6d57/auth/login', async (c) => {
  try {
    const { email, password } = await c.req.json()

    if (!email || !password) {
      return c.json({ error: 'Email and password are required' }, 400)
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      console.log('Login error:', error)
      return c.json({ error: 'Invalid credentials' }, 401)
    }

    // Get user profile
    const userType = data.user.user_metadata?.userType
    let profile = null

    if (userType === 'therapist') {
      profile = await kv.get(`therapist:${data.user.id}`)
    } else if (userType === 'client') {
      profile = await kv.get(`client:${data.user.id}`)
    }

    return c.json({
      success: true,
      user: {
        id: data.user.id,
        email: data.user.email,
        userType,
        profile
      },
      session: data.session
    })
  } catch (error) {
    console.log('Error in login:', error)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Get platform statistics for admin/investor dashboard
app.get('/make-server-7d2f6d57/stats', async (c) => {
  try {
    const therapistInterests = await kv.getByPrefix('therapist_interest:')
    const clientKeys = await kv.getByPrefix('client:')
    
    // Count by practice area
    const otCount = therapistInterests.filter(t => t.practiceArea === 'OT').length
    const ptCount = therapistInterests.filter(t => t.practiceArea === 'PT').length
    const slpCount = therapistInterests.filter(t => t.practiceArea === 'SLP').length
    
    const totalInterests = therapistInterests.length
    const totalClients = clientKeys.length

    return c.json({
      therapistInterests: {
        total: totalInterests,
        byArea: {
          OT: otCount,
          PT: ptCount,
          SLP: slpCount
        }
      },
      clients: {
        total: totalClients
      },
      engagement: {
        totalSignups: totalInterests + totalClients,
        growthRate: '34%' // Static for demo
      }
    })
  } catch (error) {
    console.log('Error fetching stats:', error)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

Deno.serve(app.fetch)