
  # AzenCare Website

  This is a code bundle for AzenCare Website. The original project is available at https://www.figma.com/design/7mIS1Y7XLsRcwTjf6ESEm2/AzenCare-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  